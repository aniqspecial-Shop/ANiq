-- Live, publicly readable shop data ------------------------------------------
CREATE TABLE public.site_content (
  id text PRIMARY KEY,
  data jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.site_content TO anon, authenticated;
GRANT ALL ON public.site_content TO service_role;
ALTER TABLE public.site_content ENABLE ROW LEVEL SECURITY;
CREATE POLICY "site content is public" ON public.site_content FOR SELECT TO anon, authenticated USING (true);

CREATE TABLE public.products (
  id text PRIMARY KEY,
  name text NOT NULL DEFAULT '',
  price numeric NOT NULL DEFAULT 0,
  category text NOT NULL DEFAULT '',
  image text NOT NULL DEFAULT '',
  images jsonb NOT NULL DEFAULT '[]'::jsonb,
  video text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  in_stock boolean NOT NULL DEFAULT true,
  vat_rate numeric,
  shipping_fee numeric,
  discount_pct numeric,
  sort_order integer NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.products TO anon, authenticated;
GRANT ALL ON public.products TO service_role;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
CREATE POLICY "products are public" ON public.products FOR SELECT TO anon, authenticated USING (true);

-- Admin-only drafts (never exposed to the Data API) ---------------------------
CREATE TABLE public.drafts (
  id text PRIMARY KEY,
  data jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.drafts TO service_role;
ALTER TABLE public.drafts ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.admin_config (
  id boolean PRIMARY KEY DEFAULT true CHECK (id),
  password text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.admin_config TO service_role;
ALTER TABLE public.admin_config ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.admin_sessions (
  token text PRIMARY KEY,
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL
);
GRANT ALL ON public.admin_sessions TO service_role;
ALTER TABLE public.admin_sessions ENABLE ROW LEVEL SECURITY;

-- Orders ----------------------------------------------------------------------
CREATE TABLE public.orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ref text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  approved_at timestamptz,
  name text NOT NULL DEFAULT '',
  phone text NOT NULL DEFAULT '',
  note text NOT NULL DEFAULT '',
  items jsonb NOT NULL DEFAULT '[]'::jsonb,
  subtotal numeric NOT NULL DEFAULT 0,
  discount numeric NOT NULL DEFAULT 0,
  vat numeric NOT NULL DEFAULT 0,
  shipping numeric NOT NULL DEFAULT 0,
  total numeric NOT NULL DEFAULT 0,
  ngn_rate numeric NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'pending',
  receipt text NOT NULL DEFAULT ''
);
GRANT ALL ON public.orders TO service_role;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

-- Analytics -------------------------------------------------------------------
CREATE TABLE public.analytics_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL,
  label text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT INSERT ON public.analytics_events TO anon, authenticated;
GRANT ALL ON public.analytics_events TO service_role;
ALTER TABLE public.analytics_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "anyone can record events" ON public.analytics_events
  FOR INSERT TO anon, authenticated
  WITH CHECK (type IN ('view', 'product', 'ad', 'cart', 'checkout') AND length(label) <= 200);
CREATE INDEX analytics_events_created_idx ON public.analytics_events (created_at DESC);

-- Realtime --------------------------------------------------------------------
ALTER TABLE public.products REPLICA IDENTITY FULL;
ALTER TABLE public.site_content REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.products;
ALTER PUBLICATION supabase_realtime ADD TABLE public.site_content;

-- Seed ------------------------------------------------------------------------
INSERT INTO public.admin_config (id, password) VALUES (true, 'Woara@2026');
INSERT INTO public.site_content (id, data) VALUES ('live', '{}'::jsonb);

INSERT INTO public.products (id, name, price, category, image, images, video, description, in_stock, sort_order) VALUES
('p1','Charcoal Brushstroke Palazzo',120,'Palazzo','/__l5e/assets-v1/f01eb5b8-49c5-4d01-aa61-34117263047d/Screenshot_2026-08-13_163433.png','["/__l5e/assets-v1/f01eb5b8-49c5-4d01-aa61-34117263047d/Screenshot_2026-08-13_163433.png","/__l5e/assets-v1/09c4b5ff-5388-4c3a-b8a8-65057c8c51ed/Screenshot_2026-08-13_163543.png"]'::jsonb,'','Wide-leg palazzo trousers in a hand-printed charcoal brushstroke adire. Drawstring waist, deep pockets, unlined for breathability.',true,1),
('p2','Amethyst Marble Palazzo',135,'Palazzo','/__l5e/assets-v1/52e713a8-803a-4a55-bc91-e57816860b6a/Screenshot_2026-08-13_163336.png','["/__l5e/assets-v1/52e713a8-803a-4a55-bc91-e57816860b6a/Screenshot_2026-08-13_163336.png","/__l5e/assets-v1/7500c68b-bc0b-4bdf-8c59-29eb072f2e60/Screenshot_2026-08-13_163525.png"]'::jsonb,'','Purple and gold tie-dye marbling on soft cotton. Elasticated waist with a flowing wide leg that moves with you.',true,2),
('p3','Patchwork Heritage Palazzo',180,'Limited','/__l5e/assets-v1/09c4b5ff-5388-4c3a-b8a8-65057c8c51ed/Screenshot_2026-08-13_163543.png','["/__l5e/assets-v1/09c4b5ff-5388-4c3a-b8a8-65057c8c51ed/Screenshot_2026-08-13_163543.png","/__l5e/assets-v1/f01eb5b8-49c5-4d01-aa61-34117263047d/Screenshot_2026-08-13_163433.png"]'::jsonb,'','A one-of-one patchwork of vintage adire panels — emerald, indigo and ochre stitched into a single statement piece.',true,3),
('p4','Teal Feather Ankara Palazzo',145,'Ankara','/__l5e/assets-v1/7500c68b-bc0b-4bdf-8c59-29eb072f2e60/Screenshot_2026-08-13_163525.png','["/__l5e/assets-v1/7500c68b-bc0b-4bdf-8c59-29eb072f2e60/Screenshot_2026-08-13_163525.png","/__l5e/assets-v1/52e713a8-803a-4a55-bc91-e57816860b6a/Screenshot_2026-08-13_163336.png"]'::jsonb,'','Bold teal and citrine feather-print ankara, cut full through the leg with a relaxed high waist.',true,4);