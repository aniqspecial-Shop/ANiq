-- Defense in depth: these tables are only ever touched by trusted server code
-- (service role). Make the denial explicit at the privilege level too, so a
-- future permissive policy can never accidentally expose them to the Data API.

ALTER TABLE public.admin_config ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.drafts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.site_content ENABLE ROW LEVEL SECURITY;

ALTER TABLE public.admin_config FORCE ROW LEVEL SECURITY;
ALTER TABLE public.admin_sessions FORCE ROW LEVEL SECURITY;

REVOKE ALL ON public.admin_config FROM anon, authenticated;
REVOKE ALL ON public.admin_sessions FROM anon, authenticated;
REVOKE ALL ON public.drafts FROM anon, authenticated;
REVOKE ALL ON public.orders FROM anon, authenticated;

GRANT ALL ON public.admin_config TO service_role;
GRANT ALL ON public.admin_sessions TO service_role;
GRANT ALL ON public.drafts TO service_role;
GRANT ALL ON public.orders TO service_role;

-- Public site content stays readable, but writes are server-only.
REVOKE INSERT, UPDATE, DELETE ON public.site_content FROM anon, authenticated;
GRANT SELECT ON public.site_content TO anon, authenticated;
GRANT ALL ON public.site_content TO service_role;
