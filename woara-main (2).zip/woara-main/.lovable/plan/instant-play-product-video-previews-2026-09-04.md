# Instant-play product video previews

Today the product "Preview the dress" popup drops a social embed (Instagram/TikTok/X) into the frame, so shoppers see a post card with captions, avatars and a play button instead of the garment moving. Fix: play the video itself whenever we can, and fall back to the cleanest possible embed only when the platform gives us no choice.

## What changes

1. **Direct video files play instantly.** Any `.mp4/.webm/.mov` link — pasted or uploaded in the admin product editor — renders as a native player that autoplays muted, loops and shows controls. No click needed.
2. **Admin gets a second video field.** On each product: "Video link (any platform)" plus "Direct video file (plays instantly)" with upload support, same pattern as the existing image field. If the direct file is present, it wins in the popup.
3. **Cleanest possible embeds for social links.** Where the platform supports it, drop chrome and force immediate playback: YouTube (`autoplay=1&mute=1&controls=1&modestbranding=1&rel=0`), Vimeo (`autoplay=1&muted=1&title=0&byline=0&portrait=0`), Streamable, Loom, Wistia, Dailymotion, Drive. Instagram switches from the captioned embed to the plain one so no caption block renders.
4. **Honest fallback note.** Instagram, TikTok and X block muted autoplay from third-party sites, so their players still need one tap. When only such a link exists, the popup shows a small line: "Tap play — this platform requires it. Add a direct video file in the admin for instant playback."
5. **Popup stays** — same modal, just playing immediately on open instead of showing a post card.

## Technical notes

- `src/lib/video.ts`: extend `ResolvedVideo` with `instant: boolean` (true for file/YouTube/Vimeo/Loom/etc., false for ig/tiktok/x/facebook); tighten the per-provider query params above; Instagram uses `/embed/` not `/embed/captioned/`.
- `src/components/Modal.tsx` `VideoModal`: accept an optional `file` prop; prefer resolving that first, then the link. Native `<video>` gets `autoPlay muted loop playsInline controls`; render the fallback hint when `!instant`.
- Product type in `src/lib/products.ts`: add optional `videoFile`; include it in CRUD, CSV import/export headers and the sample template.
- `src/routes/admin.tsx` product editor: add the direct-file field (upload or URL) next to the existing video link field.
- `src/routes/product.$id.tsx`: pass both `product.videoFile` and `product.video` to `VideoModal`.
- No schema change needed if products are stored as JSON rows; if the products table has typed columns, add a nullable `video_file` column via migration and regenerate types.
