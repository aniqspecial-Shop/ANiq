import { useContent } from "@/lib/content";
import { trackAdClick } from "@/lib/analytics";

export function AdBanner() {
  const ads = useContent().ads.filter((a) => a.active);
  if (!ads.length) return null;

  return (
    <div className="space-y-2 px-5 pt-5 sm:px-10 lg:px-16">
      {ads.map((ad) => (
        <a
          key={ad.id}
          href={ad.ctaUrl || "#"}
          onClick={() => trackAdClick(ad.id)}
          className="group grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-4 overflow-hidden rounded-md border border-accent/30 bg-gradient-to-r from-secondary via-card to-secondary px-3 py-2.5 transition-colors hover:border-accent/70"
        >
          {ad.image ? (
            <img
              src={ad.image}
              alt=""
              className="h-11 w-11 shrink-0 rounded-sm object-cover"
              loading="lazy"
            />
          ) : (
            <span className="h-11 w-11 shrink-0 rounded-sm bg-accent/20" />
          )}
          <span className="min-w-0">
            <span className="block truncate wordmark text-[10px] text-accent">{ad.title}</span>
            <span className="block truncate text-xs text-muted-foreground">{ad.text}</span>
          </span>
          {ad.ctaLabel && (
            <span className="shrink-0 rounded-sm bg-accent px-3 py-1.5 wordmark text-[10px] text-accent-foreground transition-transform group-hover:-translate-y-0.5">
              {ad.ctaLabel}
            </span>
          )}
        </a>
      ))}
    </div>
  );
}
