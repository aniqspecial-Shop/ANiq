import { useEffect } from "react";
import { useContent } from "@/lib/content";
import { themeToCss } from "@/lib/theme";

/** Injects the admin-editable theme tokens as CSS variables for the whole site. */
export function ThemeStyle() {
  const content = useContent();
  const { logo, theme } = content;

  useEffect(() => {
    if (typeof document === "undefined") return;

    const href =
      logo.mode === "image" && logo.image
        ? logo.image
        : textFavicon(
            `${logo.primary ?? ""}`.trim().slice(0, 2) || "W",
            theme.tokens?.background ?? "#0b1020",
            theme.tokens?.accent ?? "#d4af37",
          );

    document.querySelectorAll<HTMLLinkElement>("link[rel~='icon']").forEach((l) => l.remove());
    const link = document.createElement("link");
    link.rel = "icon";
    link.href = href;
    if (href.startsWith("data:image/svg")) link.type = "image/svg+xml";
    document.head.appendChild(link);
  }, [logo.mode, logo.image, logo.primary, theme.tokens]);

  return <style dangerouslySetInnerHTML={{ __html: `:root{${themeToCss(theme.tokens)}}` }} />;
}

/** Builds a crisp square favicon from the wordmark when no image logo is set. */
function textFavicon(text: string, bg: string, fg: string) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="12" fill="${bg}"/><text x="32" y="43" font-family="Georgia,serif" font-size="34" text-anchor="middle" fill="${fg}">${text}</text></svg>`;
  return `data:image/svg+xml,${encodeURIComponent(svg)}`;
}
