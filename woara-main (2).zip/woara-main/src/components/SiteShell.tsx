import { Link } from "@tanstack/react-router";
import { Menu, X, Instagram, ShoppingBag } from "lucide-react";
import { useState, type ReactNode } from "react";
import { AdBanner } from "@/components/AdBanner";
import { cartCount, useCart } from "@/lib/cart";
import { useContent } from "@/lib/content";
import { ThemeStyle } from "@/components/ThemeProvider";

const nav = [
  { to: "/", label: "Shop" },
  { to: "/gallery", label: "Gallery" },
  { to: "/about", label: "About Us" },
  { to: "/contact", label: "Contact Us" },
  { to: "/cart", label: "Cart" },
  { to: "/admin", label: "Admin" },
] as const;

function Wordmark({ className = "" }: { className?: string }) {
  const logo = useContent().logo;
  if (logo.mode === "image" && logo.image) {
    return (
      <Link to="/" className={`inline-block ${className}`}>
        <img src={logo.image} alt="Wọ Àrá" className="h-9 w-auto max-w-[150px] object-contain" />
      </Link>
    );
  }
  return (
    <Link to="/" className={`wordmark inline-flex items-baseline gap-2 text-foreground ${className}`}>
      <span className="text-lg sm:text-xl">{logo.primary}</span>
      <span className="text-lg sm:text-xl gold-text">{logo.secondary}</span>
    </Link>
  );
}

export function SiteShell({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const count = cartCount(useCart());
  const content = useContent();

  return (
    <div className="min-h-screen bg-background lg:pr-[264px]">
      <ThemeStyle />
      {/* Mobile bar */}
      <header className="sticky top-0 z-40 grid grid-cols-[minmax(0,1fr)_auto_auto] items-center gap-3 border-b border-border bg-background/90 px-5 py-4 backdrop-blur lg:hidden">
        <Wordmark />
        <Link to="/cart" className="relative shrink-0 rounded-sm border border-border p-2 text-foreground">
          <ShoppingBag className="h-4 w-4" />
          {count > 0 && (
            <span className="absolute -right-1.5 -top-1.5 grid h-4 min-w-4 place-items-center rounded-full bg-accent px-1 text-[10px] font-bold text-accent-foreground">
              {count}
            </span>
          )}
        </Link>
        <button
          aria-label={open ? "Close menu" : "Open menu"}
          onClick={() => setOpen((v) => !v)}
          className="shrink-0 rounded-sm border border-border p-2 text-foreground"
        >
          {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
        </button>
      </header>

      {open && (
        <nav className="fixed inset-x-0 top-[61px] z-40 border-b border-border bg-background px-5 py-6 lg:hidden">
          <ul className="space-y-4">
            {nav.map((n) => (
              <li key={n.to}>
                <Link
                  to={n.to}
                  onClick={() => setOpen(false)}
                  className="wordmark text-sm text-muted-foreground"
                  activeProps={{ className: "wordmark text-sm text-accent" }}
                  activeOptions={{ exact: n.to === "/" }}
                >
                  {n.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      )}

      {/* Right sidebar (desktop) */}
      <aside className="fixed right-0 top-0 z-40 hidden h-screen w-[264px] flex-col justify-between border-l border-border bg-card px-8 py-10 lg:flex">
        <div>
          <Wordmark className="text-xl" />
          <p className="mt-4 text-xs leading-relaxed text-muted-foreground">{content.settings.tagline}</p>
        </div>

        <nav>
          <ul className="space-y-5">
            {nav.map((n) => (
              <li key={n.to}>
                <Link
                  to={n.to}
                  className="wordmark hairline-link text-sm text-muted-foreground transition-colors hover:text-accent"
                  activeProps={{ className: "wordmark hairline-link text-sm text-accent" }}
                  activeOptions={{ exact: n.to === "/" }}
                >
                  {n.label}
                  {n.to === "/cart" && count > 0 ? ` (${count})` : ""}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div className="space-y-3 text-xs text-muted-foreground">
          <a
            href={content.contact.instagram}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 hairline-link hover:text-accent"
          >
            <Instagram className="h-3.5 w-3.5" /> @wo.ara
          </a>
          <p>© {new Date().getFullYear()} Wọ Àrá</p>
        </div>
      </aside>

      <AdBanner />
      <main>{children}</main>

      <footer className="border-t border-border px-5 py-10 sm:px-10 lg:px-16">
        <Wordmark />
        <p className="mt-3 text-xs text-muted-foreground">
          © {new Date().getFullYear()} Wọ Àrá — Lagos
        </p>
      </footer>
    </div>
  );
}
