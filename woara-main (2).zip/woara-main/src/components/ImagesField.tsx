import { Plus, Trash2 } from "lucide-react";
import { ImageField } from "@/components/ImageField";

/** Repeating image inputs — each row accepts an upload or a link. */
export function ImagesField({
  values,
  onChange,
  label = "Additional images",
}: {
  values: string[];
  onChange: (v: string[]) => void;
  label?: string;
}) {
  return (
    <div className="space-y-3 rounded-sm border border-border p-3">
      <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
        <span className="wordmark text-[10px] text-accent">{label}</span>
        <button
          type="button"
          onClick={() => onChange([...values, ""])}
          className="inline-flex items-center gap-2 rounded-sm border border-border px-3 py-1.5 wordmark text-[10px] text-muted-foreground hover:border-accent hover:text-accent"
        >
          <Plus className="h-3 w-3" /> Add image
        </button>
      </div>
      {values.length === 0 && <p className="text-xs text-muted-foreground">No extra images yet.</p>}
      {values.map((v, i) => (
        <div key={i} className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3">
          <ImageField
            label={`Image ${i + 1}`}
            value={v}
            onChange={(nv) => onChange(values.map((x, j) => (j === i ? nv : x)))}
          />
          <button
            type="button"
            aria-label={`Remove image ${i + 1}`}
            onClick={() => onChange(values.filter((_, j) => j !== i))}
            className="rounded-sm border border-destructive/50 p-2 text-destructive"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        </div>
      ))}
    </div>
  );
}
