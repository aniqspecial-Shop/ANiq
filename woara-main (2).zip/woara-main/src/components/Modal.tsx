import { X } from "lucide-react";
import { useEffect, type ReactNode } from "react";
import { bestVideo } from "@/lib/video";

export function Modal({
  open,
  onClose,
  children,
  wide,
  label,
}: {
  open: boolean;
  onClose: () => void;
  children: ReactNode;
  wide?: boolean;
  label?: string;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={label ?? "Dialog"}
      className="fixed inset-0 z-[70] grid place-items-center bg-background/80 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className={`relative w-full ${wide ? "max-w-3xl" : "max-w-md"} animate-fade-up rounded-sm border border-accent/30 bg-card p-6 glow-ring`}
      >
        <button
          onClick={onClose}
          aria-label="Close"
          className="absolute right-3 top-3 rounded-sm border border-border p-1.5 text-muted-foreground hover:text-accent"
        >
          <X className="h-4 w-4" />
        </button>
        {children}
      </div>
    </div>
  );
}

export function VideoModal({
  open,
  onClose,
  url,
  file,
  title,
}: {
  open: boolean;
  onClose: () => void;
  url: string;
  file?: string;
  title: string;
}) {
  const video = bestVideo(file, url, { autoplay: true, muted: true, loop: true });
  const original = video.provider === "file" && file ? file : url;

  return (
    <Modal open={open} onClose={onClose} wide label={title}>
      <p className="wordmark text-[10px] text-accent">Preview</p>
      <h3 className="mt-2 truncate text-xl">{title}</h3>
      <div
        className={`mx-auto mt-4 w-full overflow-hidden rounded-sm bg-secondary ${
          video.portrait ? "aspect-[9/16] max-h-[70vh] max-w-sm" : "aspect-video"
        }`}
      >
        {video.kind === "iframe" ? (
          <iframe
            src={video.src}
            title={title}
            allow="autoplay; fullscreen; encrypted-media; picture-in-picture; clipboard-write"
            referrerPolicy="strict-origin-when-cross-origin"
            allowFullScreen
            className="h-full w-full border-0"
          />
        ) : video.kind === "file" ? (
          <video
            src={video.src}
            controls
            autoPlay
            muted
            loop
            playsInline
            preload="auto"
            className="h-full w-full object-contain"
          />
        ) : (
          <div className="grid h-full place-items-center text-xs text-muted-foreground">No video added yet.</div>
        )}
      </div>
      {video.kind !== "none" && !video.instant && (
        <p className="mt-3 text-xs text-muted-foreground">
          Tap play — this platform requires it. Add a direct video file in the admin for instant playback.
        </p>
      )}
      {video.kind !== "none" && (
        <a
          href={original}
          target="_blank"
          rel="noreferrer"
          className="mt-3 inline-block hairline-link wordmark text-[10px] text-muted-foreground hover:text-accent"
        >
          Open original
        </a>
      )}
    </Modal>
  );
}

