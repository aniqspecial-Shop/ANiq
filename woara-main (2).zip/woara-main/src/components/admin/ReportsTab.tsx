import { useMemo, useState } from "react";
import { Download } from "lucide-react";
import { Btn, Panel } from "@/components/admin/ui";
import { useOrders, type Order } from "@/lib/orders";
import { ngn, usd } from "@/lib/cart";
import { download, toCsv } from "@/lib/csv";
import { useContent } from "@/lib/content";
import { SheetsPanel } from "@/components/admin/SheetsPanel";

const dayKey = (t: number) => new Date(t).toISOString().slice(0, 10);

export function ReportsTab() {
  const orders = useOrders();
  const rate = useContent().settings.ngnRate;
  const [scope, setScope] = useState<"approved" | "all">("approved");

  const rows = useMemo(
    () => orders.filter((o) => (scope === "all" ? o.status !== "cancelled" : o.status === "approved")),
    [orders, scope],
  );

  const revenue = rows.reduce((s, o) => s + o.total, 0);
  const vat = rows.reduce((s, o) => s + o.vat, 0);
  const units = rows.reduce((s, o) => s + o.items.reduce((n, i) => n + i.qty, 0), 0);
  const avg = rows.length ? revenue / rows.length : 0;

  const byDay = useMemo(() => {
    const m = new Map<string, number>();
    for (const o of rows) m.set(dayKey(o.createdAt), (m.get(dayKey(o.createdAt)) ?? 0) + o.total);
    return [...m.entries()].sort((a, b) => a[0].localeCompare(b[0])).slice(-14);
  }, [rows]);

  const byProduct = useMemo(() => {
    const m = new Map<string, { name: string; qty: number; value: number }>();
    for (const o of rows)
      for (const i of o.items) {
        const e = m.get(i.id) ?? { name: i.name, qty: 0, value: 0 };
        e.qty += i.qty;
        e.value += i.price * i.qty;
        m.set(i.id, e);
      }
    return [...m.values()].sort((a, b) => b.value - a.value);
  }, [rows]);

  const max = Math.max(1, ...byDay.map(([, v]) => v));

  function exportCsv() {
    const head = [
      "ref",
      "date",
      "status",
      "customer",
      "phone",
      "items",
      "subtotal_usd",
      "discount_usd",
      "vat_usd",
      "shipping_usd",
      "total_usd",
      "total_ngn",
    ];
    const body = rows.map((o: Order) => [
      o.ref,
      new Date(o.createdAt).toISOString(),
      o.status,
      o.name,
      o.phone,
      o.items.map((i) => `${i.name} x${i.qty}`).join(" | "),
      o.subtotal.toFixed(2),
      o.discount.toFixed(2),
      o.vat.toFixed(2),
      o.shipping.toFixed(2),
      o.total.toFixed(2),
      Math.round(o.total * (o.ngnRate || rate)),
    ]);
    download(`wo-ara-sales-${dayKey(Date.now())}.csv`, toCsv([head, ...body]));
  }

  const stats = [
    { label: "Revenue (USD)", value: usd(revenue) },
    { label: "Revenue (NGN)", value: ngn(revenue * rate) },
    { label: "Orders", value: String(rows.length) },
    { label: "Units sold", value: String(units) },
    { label: "Average order", value: usd(avg) },
    { label: "VAT collected", value: usd(vat) },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center gap-2">
        {(["approved", "all"] as const).map((s) => (
          <button
            key={s}
            onClick={() => setScope(s)}
            className={`rounded-sm px-3 py-1.5 wordmark text-[10px] ${
              scope === s ? "bg-accent text-accent-foreground" : "border border-border text-muted-foreground hover:text-accent"
            }`}
          >
            {s === "approved" ? "Approved sales" : "All live orders"}
          </button>
        ))}
        <Btn tone="gold" onClick={exportCsv}>
          <Download className="h-3 w-3" /> Export CSV
        </Btn>
      </div>

      <div className="grid gap-3 sm:grid-cols-3">
        {stats.map((s) => (
          <div key={s.label} className="rounded-sm border border-border bg-card p-5 glow-ring">
            <p className="wordmark text-[10px] text-muted-foreground">{s.label}</p>
            <p className="mt-2 truncate text-2xl text-accent">{s.value}</p>
          </div>
        ))}
      </div>

      <Panel title="Revenue — last 14 days">
        {byDay.length === 0 ? (
          <p className="text-sm text-muted-foreground">No sales recorded yet.</p>
        ) : (
          <div className="flex h-44 items-end gap-2">
            {byDay.map(([d, v]) => (
              <div key={d} className="grid min-w-0 flex-1 justify-items-center gap-2">
                <span className="text-[10px] text-muted-foreground">{Math.round(v)}</span>
                <div
                  className="w-full rounded-t-sm bg-accent/80 transition-all"
                  style={{ height: `${Math.max(4, (v / max) * 120)}px` }}
                  title={`${d}: ${usd(v)}`}
                />
                <span className="truncate text-[9px] text-muted-foreground">{d.slice(5)}</span>
              </div>
            ))}
          </div>
        )}
      </Panel>

      <Panel title="Best sellers">
        <ul className="space-y-2 text-sm">
          {byProduct.length === 0 && <li className="text-muted-foreground">Nothing sold yet.</li>}
          {byProduct.map((p) => (
            <li key={p.name} className="grid grid-cols-[minmax(0,1fr)_auto] gap-3 border-b border-border pb-2">
              <span className="truncate text-muted-foreground">
                {p.name} · {p.qty} sold
              </span>
              <span className="text-accent">{usd(p.value)}</span>
            </li>
          ))}
        </ul>
      </Panel>
      <SheetsPanel />
    </div>
  );
}
