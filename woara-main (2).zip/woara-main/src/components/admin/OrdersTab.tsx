import { useState } from "react";
import { Check, Trash2, Clock, Ban } from "lucide-react";
import { Btn, Panel, Toggle } from "@/components/admin/ui";
import { ImageField } from "@/components/ImageField";
import { approveOrder, orderDate, removeOrder, updateOrder, useOrders, type Order } from "@/lib/orders";
import { ngn, usd } from "@/lib/cart";
import { updateContent, useAdminContent } from "@/lib/content";

const statusTone: Record<Order["status"], string> = {
  pending: "text-accent",
  approved: "text-emerald-400",
  cancelled: "text-destructive",
};

export function OrdersTab() {
  const orders = useOrders();
  const { approvals } = useAdminContent();
  const [filter, setFilter] = useState<"all" | Order["status"]>("all");
  const [err, setErr] = useState<Record<string, string>>({});

  const list = orders.filter((o) => filter === "all" || o.status === filter);

  function tryApprove(o: Order) {
    if (approvals.requireReceipt && !o.receipt) {
      setErr((e) => ({ ...e, [o.id]: "Upload the payment receipt before approving." }));
      return;
    }
    setErr((e) => ({ ...e, [o.id]: "" }));
    approveOrder(o.id);
  }

  return (
    <div className="space-y-6">
      <Panel title="Approval settings">
        <Toggle
          checked={approvals.requireReceipt}
          onChange={(v) => updateContent((x) => ((x.approvals.requireReceipt = v), x))}
          label="Require a payment receipt screenshot before a sale can be approved"
        />
        <p className="text-xs text-muted-foreground">
          When off, an order can be approved straight after the WhatsApp payment is confirmed.
        </p>
      </Panel>

      <div className="flex flex-wrap gap-2">
        {(["all", "pending", "approved", "cancelled"] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`rounded-sm px-3 py-1.5 wordmark text-[10px] ${
              filter === f ? "bg-accent text-accent-foreground" : "border border-border text-muted-foreground hover:text-accent"
            }`}
          >
            {f} ({f === "all" ? orders.length : orders.filter((o) => o.status === f).length})
          </button>
        ))}
      </div>

      {list.length === 0 && <p className="text-sm text-muted-foreground">No orders here yet.</p>}

      {list.map((o) => (
        <Panel
          key={o.id}
          title={`${o.ref} — ${o.name || "No name"}`}
          action={<span className={`wordmark text-[10px] ${statusTone[o.status]}`}>{o.status}</span>}
        >
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1 text-sm">
              <p className="text-muted-foreground">
                <Clock className="mr-2 inline h-3.5 w-3.5" />
                Placed {orderDate(o.createdAt)}
              </p>
              {o.approvedAt && <p className="text-emerald-400">Approved {orderDate(o.approvedAt)}</p>}
              <p>
                Phone: <span className="text-accent">{o.phone || "—"}</span>
              </p>
              {o.note && <p className="text-muted-foreground">Note: {o.note}</p>}
            </div>
            <ul className="space-y-1 text-xs text-muted-foreground">
              {o.items.map((i) => (
                <li key={i.id} className="truncate">
                  {i.name} × {i.qty} — {usd(i.price * i.qty)}
                </li>
              ))}
            </ul>
          </div>

          <dl className="grid grid-cols-2 gap-x-6 gap-y-1 border-t border-border pt-4 text-sm sm:grid-cols-3">
            <Row k="Subtotal" v={usd(o.subtotal)} />
            <Row k="Discount" v={`- ${usd(o.discount)}`} />
            <Row k="VAT" v={usd(o.vat)} />
            <Row k="Shipping" v={usd(o.shipping)} />
            <Row k="Total" v={usd(o.total)} />
            <Row k="Total (NGN)" v={ngn(o.total * o.ngnRate)} />
          </dl>

          <ImageField
            label="Payment receipt"
            value={o.receipt}
            onChange={(v) => updateOrder(o.id, { receipt: v })}
          />
          {err[o.id] && <p className="text-xs text-destructive">{err[o.id]}</p>}

          <div className="flex flex-wrap gap-2">
            {o.status !== "approved" && (
              <Btn tone="gold" onClick={() => tryApprove(o)}>
                <Check className="h-3 w-3" /> Approve sale
              </Btn>
            )}
            {o.status !== "cancelled" && (
              <Btn onClick={() => updateOrder(o.id, { status: "cancelled" })}>
                <Ban className="h-3 w-3" /> Cancel
              </Btn>
            )}
            <Btn tone="danger" onClick={() => removeOrder(o.id)}>
              <Trash2 className="h-3 w-3" /> Delete
            </Btn>
          </div>
        </Panel>
      ))}
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="grid grid-cols-[minmax(0,1fr)_auto] gap-2">
      <dt className="truncate text-muted-foreground">{k}</dt>
      <dd className="text-accent">{v}</dd>
    </div>
  );
}
