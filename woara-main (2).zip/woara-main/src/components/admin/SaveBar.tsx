import { useState } from "react";
import { CheckCircle2, Lock, Save, Undo2 } from "lucide-react";
import { Btn, Field } from "@/components/admin/ui";
import { Modal } from "@/components/Modal";
import { discardContentDraft, publishContentDraft, useHasContentDraft } from "@/lib/content";
import { discardProductDraft, publishProductDraft, useHasProductDraft } from "@/lib/products";
import { adminToken } from "@/lib/admin-session";
import { discardDrafts, publishDrafts } from "@/lib/shop.functions";

/**
 * Admin edits are held as pending changes until they are saved with the admin
 * password — saving publishes them to the live shop for every visitor at once.
 */
export function SaveBar() {
  const contentDirty = useHasContentDraft();
  const productsDirty = useHasProductDraft();
  const dirty = contentDirty || productsDirty;

  const [ask, setAsk] = useState(false);
  const [pw, setPw] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [saved, setSaved] = useState(false);

  async function save() {
    setBusy(true);
    try {
      const res = await publishDrafts({ data: { token: adminToken(), password: pw } });
      if (!res.ok) {
        setErr(res.error ?? "Wrong admin password — nothing was published.");
        return;
      }
      publishContentDraft();
      publishProductDraft();
      setAsk(false);
      setPw("");
      setErr("");
      setSaved(true);
      window.setTimeout(() => setSaved(false), 3500);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Could not publish — try again.");
    } finally {
      setBusy(false);
    }
  }

  function discard() {
    discardContentDraft();
    discardProductDraft();
    void discardDrafts({ data: { token: adminToken() } });
  }

  const changes = [contentDirty && "page content", productsDirty && "products"].filter(Boolean).join(" and ");

  return (
    <>
      <div className="fixed inset-x-4 bottom-4 z-50 mx-auto max-w-3xl lg:right-[280px] lg:left-16 lg:mx-0 lg:max-w-2xl">
        <div
          className={`grid grid-cols-1 items-center gap-3 rounded-sm border p-4 backdrop-blur sm:grid-cols-[minmax(0,1fr)_auto] ${
            dirty ? "border-accent/50 bg-card/95 glow-ring" : "border-border bg-card/90"
          }`}
        >
          <div className="min-w-0">
            <p className="wordmark text-[10px] text-accent">{dirty ? "Unsaved changes" : "All changes live"}</p>
            <p className="mt-1 truncate text-xs text-muted-foreground">
              {dirty
                ? `Pending edits to ${changes} — save to publish them to the shop.`
                : saved
                  ? "Saved — every open shop page updated instantly."
                  : "Everything you see here is what shoppers see."}
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            {dirty && (
              <Btn onClick={discard}>
                <Undo2 className="h-3 w-3" /> Discard
              </Btn>
            )}
            <button
              type="button"
              disabled={!dirty}
              onClick={() => {
                setErr("");
                setPw("");
                setAsk(true);
              }}
              className="inline-flex items-center gap-2 rounded-sm bg-accent px-5 py-2.5 wordmark text-[10px] text-accent-foreground transition-transform hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-40"
            >
              {saved && !dirty ? <CheckCircle2 className="h-3.5 w-3.5" /> : <Save className="h-3.5 w-3.5" />}
              {saved && !dirty ? "Saved" : "Save changes"}
            </button>
          </div>
        </div>
      </div>

      <Modal open={ask} onClose={() => setAsk(false)} label="Confirm with admin password">
        <p className="wordmark text-[10px] text-accent">Confirm</p>
        <h3 className="mt-2 text-xl">Publish these changes</h3>
        <p className="mt-2 text-xs text-muted-foreground">
          Enter the admin password to push your {changes || "changes"} live to the shop.
        </p>
        <form
          className="mt-5 space-y-4"
          onSubmit={(e) => {
            e.preventDefault();
            void save();
          }}
        >
          <Field label="Admin password" type="password" value={pw} onChange={setPw} />
          {err && <p className="text-xs text-destructive">{err}</p>}
          <div className="flex flex-wrap gap-2">
            <Btn tone="gold" type="submit" disabled={busy}>
              <Lock className="h-3 w-3" /> {busy ? "Publishing…" : "Save & publish"}
            </Btn>
            <Btn onClick={() => setAsk(false)}>Cancel</Btn>
          </div>
        </form>
      </Modal>
    </>
  );
}
