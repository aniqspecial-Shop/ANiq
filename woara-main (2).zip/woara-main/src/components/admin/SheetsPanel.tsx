import { useState } from "react";
import { ExternalLink, RefreshCw, Sheet } from "lucide-react";
import { useServerFn } from "@tanstack/react-start";
import { Btn, Field, Panel } from "@/components/admin/ui";
import { syncReportsToSheets, type SheetPayload } from "@/lib/sheets.functions";
import { sheetsStore, useSheets } from "@/lib/sheets";
import { useOrders } from "@/lib/orders";
import { useAdminProducts } from "@/lib/products";
import { useAnalytics } from "@/lib/analytics";
import { useContent } from "@/lib/content";

const iso = (t: number) => new Date(t).toISOString();

export function SheetsPanel() {
  const orders = useOrders();
  const products = useAdminProducts();
  const analytics = useAnalytics();
  const rate = useContent().settings.ngnRate;
  const state = useSheets();
  const sync = useServerFn(syncReportsToSheets);

  const [id, setId] = useState(state.spreadsheetId);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");

  function build(): SheetPayload[] {
    const approved = orders.filter((o) => o.status === "approved");

    return [
      {
        title: "Orders",
        rows: [
          ["ref", "date", "approved_at", "status", "customer", "phone", "note", "items", "subtotal_usd", "discount_usd", "vat_usd", "shipping_usd", "total_usd", "total_ngn"],
          ...orders.map((o) => [
            o.ref,
            iso(o.createdAt),
            o.approvedAt ? iso(o.approvedAt) : "",
            o.status,
            o.name,
            o.phone,
            o.note,
            o.items.map((i) => `${i.name} x${i.qty}`).join(" | "),
            o.subtotal.toFixed(2),
            o.discount.toFixed(2),
            o.vat.toFixed(2),
            o.shipping.toFixed(2),
            o.total.toFixed(2),
            Math.round(o.total * (o.ngnRate || rate)),
          ]),
        ],
      },
      {
        title: "Sales Report",
        rows: [
          ["metric", "value"],
          ["Approved orders", approved.length],
          ["Revenue (USD)", approved.reduce((s, o) => s + o.total, 0).toFixed(2)],
          ["Revenue (NGN)", Math.round(approved.reduce((s, o) => s + o.total * (o.ngnRate || rate), 0))],
          ["VAT collected (USD)", approved.reduce((s, o) => s + o.vat, 0).toFixed(2)],
          ["Units sold", approved.reduce((s, o) => s + o.items.reduce((n, i) => n + i.qty, 0), 0)],
          ["Pending orders", orders.filter((o) => o.status === "pending").length],
          ["Cancelled orders", orders.filter((o) => o.status === "cancelled").length],
          ["Add to cart events", analytics.addToCart],
          ["Checkouts", analytics.checkouts],
        ],
      },
      {
        title: "Products",
        rows: [
          ["id", "name", "price_usd", "category", "in_stock", "vat_rate", "shipping_fee", "discount_pct", "image", "video", "clicks"],
          ...products.map((p) => [
            p.id,
            p.name,
            p.price,
            p.category,
            p.inStock ? "true" : "false",
            p.vatRate ?? "",
            p.shippingFee ?? "",
            p.discountPct ?? "",
            p.image,
            p.video,
            analytics.productClicks[p.id] ?? 0,
          ]),
        ],
      },
      {
        title: "Views",
        rows: [
          ["page", "views"],
          ...Object.entries(analytics.pageViews).map(([k, v]) => [k, v]),
        ],
      },
      {
        title: "Clicks",
        rows: [
          ["type", "id", "clicks"],
          ...Object.entries(analytics.productClicks).map(([k, v]) => ["product", k, v]),
          ...Object.entries(analytics.adClicks).map(([k, v]) => ["ad", k, v]),
        ],
      },
      {
        title: "Activity Log",
        rows: [["time", "type", "label"], ...analytics.events.map((e) => [iso(e.t), e.type, e.label])],
      },
    ];
  }

  async function run() {
    setBusy(true);
    setErr("");
    setMsg("");
    try {
      const res = await sync({ data: { spreadsheetId: id, title: "Wọ Àrá — Reports", sheets: build() } });
      sheetsStore.set({ spreadsheetId: res.spreadsheetId, url: res.url, lastSyncedAt: res.syncedAt });
      setId(res.spreadsheetId);
      setMsg(`Synced ${res.tabs.join(", ")}`);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Sync failed.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Panel title="Google Sheets sync">
      <p className="text-xs text-muted-foreground">
        Pushes orders, sales report, products, views and clicks into tabs of one Google Sheet. Leave the ID blank to
        create a new spreadsheet in the connected Google account.
      </p>
      <Field label="Spreadsheet ID or URL (optional)" value={id} onChange={setId} />
      <div className="flex flex-wrap items-center gap-2">
        <Btn
          tone="gold"
          onClick={() => {
            if (!busy) void run();
          }}
        >
          {busy ? <RefreshCw className="h-3 w-3 animate-spin" /> : <Sheet className="h-3 w-3" />}
          {busy ? "Syncing…" : state.spreadsheetId ? "Sync now" : "Create & sync"}
        </Btn>
        {state.url && (
          <a
            href={state.url}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 rounded-sm border border-border px-4 py-2 wordmark text-[10px] text-muted-foreground hover:text-accent"
          >
            <ExternalLink className="h-3 w-3" /> Open sheet
          </a>
        )}
      </div>
      {state.lastSyncedAt > 0 && (
        <p className="text-xs text-muted-foreground">Last synced {new Date(state.lastSyncedAt).toLocaleString()}</p>
      )}
      {msg && <p className="text-xs text-accent">{msg}</p>}
      {err && <p className="text-xs text-destructive">{err}</p>}
    </Panel>
  );
}
