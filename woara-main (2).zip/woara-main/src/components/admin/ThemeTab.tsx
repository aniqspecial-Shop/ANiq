import { useState } from "react";
import { Wand2, Globe, Image as ImageIcon } from "lucide-react";
import { Btn, Field, Panel } from "@/components/admin/ui";
import { ImageField } from "@/components/ImageField";
import { updateContent, useAdminContent } from "@/lib/content";
import { paletteFromImage, themePresets, type ThemeTokens } from "@/lib/theme";
import { fetchSiteColors } from "@/lib/theme.functions";

const TOKEN_LABELS: { key: keyof ThemeTokens; label: string }[] = [
  { key: "background", label: "Background" },
  { key: "foreground", label: "Text" },
  { key: "card", label: "Card" },
  { key: "secondary", label: "Surface" },
  { key: "muted", label: "Muted" },
  { key: "mutedForeground", label: "Muted text" },
  { key: "accent", label: "Accent" },
  { key: "accentForeground", label: "Accent text" },
  { key: "border", label: "Border" },
];

function setTokens(tokens: ThemeTokens, preset: string) {
  updateContent((x) => {
    x.theme.tokens = tokens;
    x.theme.preset = preset;
    return x;
  });
}

export function ThemeTab() {
  const { theme, logo } = useAdminContent();
  const [url, setUrl] = useState("");
  const [shot, setShot] = useState("");
  const [busy, setBusy] = useState("");
  const [msg, setMsg] = useState("");
  const [found, setFound] = useState<string[]>([]);

  async function adoptFromUrl() {
    setBusy("url");
    setMsg("");
    setFound([]);
    try {
      const res = await fetchSiteColors({ data: { url: url.trim() } });
      const colors = res.colors.map((c) => c.hex);
      setFound(colors);
      const tokens = tokensFromColors(colors);
      if (tokens) {
        setTokens(tokens, "custom");
        setMsg("Theme adopted from that site — tweak any swatch below.");
      } else setMsg("Found colors but couldn't build a balanced theme — pick swatches manually.");
    } catch (e) {
      setMsg(e instanceof Error ? e.message : "Could not read that site. Try a screenshot upload instead.");
    } finally {
      setBusy("");
    }
  }

  async function adoptFromShot(src: string) {
    setShot(src);
    if (!src) return;
    setBusy("shot");
    setMsg("");
    try {
      const tokens = await paletteFromImage(src);
      setTokens(tokens, "custom");
      setMsg("Theme adopted from the screenshot.");
    } catch {
      setMsg("Could not read colors from that image (it may block cross-origin reads — upload the file instead).");
    } finally {
      setBusy("");
    }
  }

  return (
    <div className="space-y-6">
      <Panel title="Theme presets">
        <div className="grid gap-3 sm:grid-cols-2">
          {themePresets.map((p) => (
            <button
              key={p.id}
              onClick={() => setTokens(p.tokens, p.id)}
              className={`grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 rounded-sm border p-3 text-left ${
                theme.preset === p.id ? "border-accent" : "border-border hover:border-accent/60"
              }`}
            >
              <span className="truncate text-sm">{p.label}</span>
              <span className="flex shrink-0 gap-1">
                {[p.tokens.background, p.tokens.card, p.tokens.accent, p.tokens.foreground].map((c) => (
                  <span key={c} className="h-5 w-5 rounded-full border border-border" style={{ background: c }} />
                ))}
              </span>
            </button>
          ))}
        </div>
      </Panel>

      <Panel title="Adopt a theme from another website">
        <div className="grid gap-3 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-end">
          <Field label="Website URL" value={url} onChange={setUrl} />
          <Btn tone="gold" onClick={adoptFromUrl}>
            <Globe className="h-3 w-3" /> {busy === "url" ? "Reading…" : "Adopt colors"}
          </Btn>
        </div>
        <p className="text-xs text-muted-foreground">
          We read the site's stylesheets and pull its dominant palette. If the site blocks bots, upload a screenshot
          instead — we'll sample the colors from the image.
        </p>
        <ImageField label="Or upload a screenshot" value={shot} onChange={adoptFromShot} />
        {busy === "shot" && <p className="text-xs text-muted-foreground">Sampling colors…</p>}
        {msg && <p className="text-xs text-accent">{msg}</p>}
        {found.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {found.map((c) => (
              <button
                key={c}
                title={`Use ${c} as accent`}
                onClick={() => setTokens({ ...theme.tokens, accent: c }, "custom")}
                className="h-7 w-7 rounded-full border border-border"
                style={{ background: c }}
              />
            ))}
          </div>
        )}
      </Panel>

      <Panel
        title="Fine-tune colors"
        action={
          <Btn onClick={() => setTokens(themePresets[0]!.tokens, themePresets[0]!.id)}>
            <Wand2 className="h-3 w-3" /> Reset
          </Btn>
        }
      >
        <div className="grid gap-4 sm:grid-cols-2">
          {TOKEN_LABELS.map(({ key, label }) => (
            <label key={key} className="grid grid-cols-[auto_minmax(0,1fr)] items-center gap-3">
              <input
                type="color"
                value={theme.tokens[key]}
                onChange={(e) => setTokens({ ...theme.tokens, [key]: e.target.value }, "custom")}
                className="h-9 w-9 cursor-pointer rounded-sm border border-border bg-transparent"
              />
              <span className="min-w-0">
                <span className="block wordmark text-[10px] text-muted-foreground">{label}</span>
                <span className="block truncate text-xs">{theme.tokens[key]}</span>
              </span>
            </label>
          ))}
        </div>
      </Panel>

      <Panel title="Logo">
        <div className="flex flex-wrap gap-2">
          {(["text", "image"] as const).map((m) => (
            <button
              key={m}
              onClick={() => updateContent((x) => ((x.logo.mode = m), x))}
              className={`rounded-sm px-3 py-1.5 wordmark text-[10px] ${
                logo.mode === m ? "bg-accent text-accent-foreground" : "border border-border text-muted-foreground"
              }`}
            >
              {m === "text" ? "Wordmark" : "Image logo"}
            </button>
          ))}
        </div>
        {logo.mode === "text" ? (
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="First word" value={logo.primary} onChange={(v) => updateContent((x) => ((x.logo.primary = v), x))} />
            <Field
              label="Second word (accent)"
              value={logo.secondary}
              onChange={(v) => updateContent((x) => ((x.logo.secondary = v), x))}
            />
          </div>
        ) : (
          <>
            <ImageField label="Logo image" value={logo.image} onChange={(v) => updateContent((x) => ((x.logo.image = v), x))} />
            <p className="inline-flex items-center gap-2 text-xs text-muted-foreground">
              <ImageIcon className="h-3.5 w-3.5" /> A transparent PNG around 400×120 works best.
            </p>
          </>
        )}
      </Panel>
    </div>
  );
}

/* pick a workable set of tokens out of a list of hex colors */
function tokensFromColors(colors: string[]): ThemeTokens | null {
  const rgb = (h: string) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16)) as [number, number, number];
  const lum = (h: string) => {
    const [r, g, b] = rgb(h);
    return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
  };
  const sat = (h: string) => {
    const c = rgb(h);
    const mx = Math.max(...c);
    const mn = Math.min(...c);
    return mx === 0 ? 0 : (mx - mn) / mx;
  };
  const valid = colors.filter((c) => /^#[0-9a-f]{6}$/i.test(c));
  if (valid.length < 3) return null;

  const bg = [...valid].sort((a, b) => Math.abs(lum(a) - 0.12) - Math.abs(lum(b) - 0.12))[0]!;
  const dark = lum(bg) < 0.5;
  const accent =
    [...valid].filter((c) => sat(c) > 0.35 && Math.abs(lum(c) - (dark ? 0.65 : 0.45)) < 0.35).sort((a, b) => sat(b) - sat(a))[0] ??
    valid.sort((a, b) => sat(b) - sat(a))[0]!;

  const shade = (h: string, t: number) => {
    const [r, g, b] = rgb(h);
    const to = dark ? 255 : 0;
    return (
      "#" +
      [r, g, b]
        .map((v) => Math.round(v + (to - v) * t).toString(16).padStart(2, "0"))
        .join("")
    );
  };

  return {
    background: bg,
    foreground: shade(bg, 0.92),
    card: shade(bg, 0.07),
    secondary: shade(bg, 0.13),
    muted: shade(bg, 0.13),
    mutedForeground: shade(bg, 0.6),
    accent,
    accentForeground: lum(accent) > 0.6 ? "#0a0c10" : "#ffffff",
    border: shade(bg, 0.2),
  };
}
