import { useRef, useState } from "react";
import { Upload, Link2 } from "lucide-react";

export function ImageField({
  value,
  onChange,
  label = "Image",
}: {
  value: string;
  onChange: (v: string) => void;
  label?: string;
}) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [error, setError] = useState("");

  function pick(file?: File | null) {
    if (!file) return;
    if (file.size > 2_500_000) {
      setError("Image too large — keep it under 2.5MB.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setError("");
      onChange(String(reader.result));
    };
    reader.readAsDataURL(file);
  }

  return (
    <div className="space-y-2">
      <span className="wordmark text-[10px] text-muted-foreground">{label}</span>
      <div className="grid grid-cols-[auto_minmax(0,1fr)] gap-3">
        <div className="h-20 w-20 shrink-0 overflow-hidden rounded-sm border border-border bg-secondary">
          {value ? <img src={value} alt="" className="h-full w-full object-cover" /> : null}
        </div>
        <div className="min-w-0 space-y-2">
          <div className="grid grid-cols-[auto_minmax(0,1fr)] items-center gap-2 rounded-sm border border-border bg-background px-2">
            <Link2 className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
            <input
              value={value.startsWith("data:") ? "" : value}
              placeholder="Paste an image link…"
              onChange={(e) => onChange(e.target.value)}
              className="w-full bg-transparent py-2 text-xs outline-none"
            />
          </div>
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            className="inline-flex items-center gap-2 rounded-sm border border-border px-3 py-1.5 wordmark text-[10px] text-muted-foreground hover:border-accent hover:text-accent"
          >
            <Upload className="h-3 w-3" /> Upload
          </button>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => pick(e.target.files?.[0])}
          />
          {error && <p className="text-[11px] text-destructive">{error}</p>}
        </div>
      </div>
    </div>
  );
}
