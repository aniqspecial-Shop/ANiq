import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useContent } from "@/lib/content";

export function HeroSlider() {
  const hero = useContent().hero;
  const slides = hero.slides;
  const [i, setI] = useState(0);

  useEffect(() => {
    if (slides.length < 2) return;
    const t = setInterval(() => setI((v) => (v + 1) % slides.length), Math.max(2000, hero.intervalMs));
    return () => clearInterval(t);
  }, [slides.length, hero.intervalMs]);

  useEffect(() => {
    if (i >= slides.length) setI(0);
  }, [slides.length, i]);

  const s = slides[Math.min(i, slides.length - 1)];
  if (!s) return null;

  return (
    <section className="relative overflow-hidden border-b border-border">
      <div className="absolute inset-0">
        {slides.map((sl, idx) => (
          <img
            key={sl.id}
            src={sl.image}
            alt=""
            className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-1000 ${
              idx === i ? "opacity-100 animate-slow-zoom" : "opacity-0"
            }`}
          />
        ))}
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/85 to-background/30" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
      </div>

      <div className="relative px-5 py-24 sm:px-10 lg:px-16 lg:py-36">
        <div key={s.id} className="animate-fade-up max-w-3xl">
          <p className="wordmark text-[11px] text-accent">{s.eyebrow}</p>
          <h1 className="mt-5 text-4xl leading-[1.05] sm:text-6xl lg:text-7xl">
            <span className="gold-text">{s.title}</span>
          </h1>
          <p className="mt-6 max-w-xl text-sm leading-relaxed text-muted-foreground sm:text-base">
            {s.subtitle}
          </p>
          {s.ctaLabel && (
            <Link
              to="/"
              hash="collection"
              className="mt-9 inline-block rounded-sm bg-accent px-8 py-4 wordmark text-[11px] text-accent-foreground transition-transform hover:-translate-y-0.5"
            >
              {s.ctaLabel}
            </Link>
          )}
        </div>

        {slides.length > 1 && (
          <div className="mt-12 flex gap-2">
            {slides.map((sl, idx) => (
              <button
                key={sl.id}
                aria-label={`Slide ${idx + 1}`}
                onClick={() => setI(idx)}
                className={`h-1 rounded-full transition-all ${
                  idx === i ? "w-12 bg-accent" : "w-6 bg-border hover:bg-electric"
                }`}
              />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
