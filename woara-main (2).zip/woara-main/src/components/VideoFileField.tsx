import { useRef, useState } from "react";
import { Upload, Link2, X } from "lucide-react";

/**
 * Direct video source for a product — a .mp4/.webm link or a small uploaded clip.
 * Whatever lands here plays instantly in the preview popup, with no social post card.
 */
export function VideoFileField({
  value,
  onChange,
  label = "Direct video file (plays instantly — .mp4, .webm or .mov)",
}: {
  value: string;
  onChange: (v: string) => void;
  label?: string;
}) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [error, setError] = useState("");

  function pick(file?: File | null) {
    if (!file) return;
    if (file.size > 5_000_000) {
      setError("Clip too large — keep uploads under 5MB, or paste a link to the video file.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setError("");
      onChange(String(reader.result));
    };
    reader.readAsDataURL(file);
  }

  const uploaded = value.startsWith("data:");

  return (
    <div className="space-y-2">
      <span className="wordmark text-[10px] text-muted-foreground">{label}</span>
      <input
        ref={fileRef}
        type="file"
        accept="video/*"
        className="hidden"
        onChange={(e) => {
          pick(e.target.files?.[0]);
          e.target.value = "";
        }}
      />
      <div className="grid grid-cols-[auto_minmax(0,1fr)] gap-3">

        <div className="h-20 w-20 shrink-0 overflow-hidden rounded-sm border border-border bg-secondary">
          {value ? <video src={value} muted playsInline className="h-full w-full object-cover" /> : null}
        </div>
        <div className="min-w-0 space-y-2">
          <div className="grid grid-cols-[auto_minmax(0,1fr)] items-center gap-2 rounded-sm border border-border bg-background px-2">
            <Link2 className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
            <input
              value={uploaded ? "" : value}
              placeholder={uploaded ? "Uploaded clip in use" : "Paste a direct video link (…/clip.mp4)…"}
              onChange={(e) => onChange(e.target.value)}
              className="w-full bg-transparent py-2 text-xs outline-none"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              className="inline-flex items-center gap-2 rounded-sm border border-border px-3 py-1.5 wordmark text-[10px] text-muted-foreground hover:border-accent hover:text-accent"
            >
              <Upload className="h-3 w-3" /> Upload clip
            </button>
            {value && (
              <button
                type="button"
                onClick={() => onChange("")}
                className="inline-flex items-center gap-2 rounded-sm border border-border px-3 py-1.5 wordmark text-[10px] text-muted-foreground hover:border-destructive hover:text-destructive"
              >
                <X className="h-3 w-3" /> Remove
              </button>
            )}
          </div>
          <p className="text-[11px] text-muted-foreground">
            Used first in the preview popup. Social links still work, but Instagram, TikTok and X always ask for a tap.
          </p>
          {error && <p className="text-[11px] text-destructive">{error}</p>}
        </div>
      </div>
    </div>
  );
}
