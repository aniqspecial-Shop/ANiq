import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ArrowLeft, Minus, Plus, PlayCircle, ShoppingBag } from "lucide-react";
import { useState } from "react";
import { SiteShell } from "@/components/SiteShell";
import { Modal, VideoModal } from "@/components/Modal";
import { formatPrice, useProducts } from "@/lib/products";
import { addToCart, ngn } from "@/lib/cart";
import { useContent } from "@/lib/content";
import { trackAddToCart, usePageView } from "@/lib/analytics";

export const Route = createFileRoute("/product/$id")({
  head: () => ({
    meta: [
      { title: "Piece — Wọ Àrá" },
      { name: "description", content: "A hand-printed palazzo piece from the current Wọ Àrá run." },
      { property: "og:title", content: "Piece — Wọ Àrá" },
      { property: "og:description", content: "A hand-printed palazzo piece from the current Wọ Àrá run." },
      { property: "og:type", content: "product" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ProductPage,
});

function ProductPage() {
  const { id } = Route.useParams();
  const product = useProducts().find((p) => p.id === id);
  const { settings, checkout } = useContent();
  const navigate = useNavigate();
  const [qty, setQty] = useState(1);
  const [active, setActive] = useState(0);
  const [video, setVideo] = useState(false);
  const [added, setAdded] = useState(false);
  usePageView(`/product/${id}`);

  if (!product) {
    return (
      <SiteShell>
        <div className="px-5 py-24 sm:px-10 lg:px-16">
          <h1 className="text-3xl">This piece is no longer listed.</h1>
          <Link to="/" className="mt-6 inline-block hairline-link wordmark text-xs text-accent">
            Back to shop
          </Link>
        </div>
      </SiteShell>
    );
  }

  const shots = [product.image, ...(product.images ?? [])].filter(Boolean);
  const hero = shots[Math.min(active, shots.length - 1)] ?? product.image;
  const discount = product.discountPct ?? checkout.discountPct;
  const vatRate = product.vatRate ?? checkout.vatRate;

  function add() {
    if (!product) return;
    addToCart(
      {
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.image,
        vatRate: product.vatRate,
        shippingFee: product.shippingFee,
        discountPct: product.discountPct,
      },
      qty,
    );
    trackAddToCart(product.name);
    setAdded(true);
  }

  return (
    <SiteShell>
      <div className="px-5 py-10 sm:px-10 lg:px-16">
        <Link
          to="/"
          className="inline-flex items-center gap-2 wordmark text-[11px] text-muted-foreground hover:text-accent"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> Shop
        </Link>

        <div className="mt-8 grid gap-10 lg:grid-cols-2">
          <div className="space-y-4">
            <img
              src={hero}
              alt={product.name}
              className="aspect-[3/4] w-full rounded-sm bg-secondary object-cover glow-ring"
            />
            {shots.length > 1 && (
              <div className="grid grid-cols-4 gap-3 sm:grid-cols-5">
                {shots.map((s, i) => (
                  <button
                    key={`${s}-${i}`}
                    onClick={() => setActive(i)}
                    aria-label={`View image ${i + 1}`}
                    className={`overflow-hidden rounded-sm border ${i === active ? "border-accent" : "border-border"}`}
                  >
                    <img src={s} alt="" className="aspect-square w-full object-cover" />
                  </button>
                ))}
              </div>
            )}

            <button
              onClick={() => setVideo(true)}
              className="group grid w-full grid-cols-[auto_minmax(0,1fr)] items-center gap-4 rounded-sm border border-accent/30 bg-card p-4 text-left transition-transform hover:-translate-y-0.5"
            >
              <span className="grid h-14 w-14 shrink-0 place-items-center rounded-sm bg-secondary sheen">
                <PlayCircle className="h-6 w-6 text-accent" />
              </span>
              <span className="min-w-0">
                <span className="block wordmark text-[10px] text-accent">Preview the dress</span>
                <span className="block truncate text-sm">See {product.name} in motion</span>
              </span>
            </button>
          </div>

          <div className="lg:pt-6">
            <p className="wordmark text-[10px] text-accent">{product.category}</p>
            <h1 className="mt-3 text-4xl sm:text-5xl">{product.name}</h1>
            <p className="mt-4 text-lg text-accent">{formatPrice(product.price)}</p>
            <p className="text-xs text-muted-foreground">≈ {ngn(product.price * settings.ngnRate)}</p>
            <p className="mt-1 text-xs text-muted-foreground">
              {discount > 0 ? `${discount}% off applied at checkout · ` : ""}
              {vatRate > 0 ? `VAT ${vatRate}% added at checkout` : "No VAT on this piece"}
            </p>
            <p className="mt-8 max-w-md text-sm leading-relaxed text-muted-foreground">{product.description}</p>

            <div className="mt-8 flex flex-wrap items-center gap-4">
              <div className="inline-flex items-center gap-4 rounded-sm border border-border px-3 py-2.5">
                <button aria-label="Decrease quantity" onClick={() => setQty((q) => Math.max(1, q - 1))}>
                  <Minus className="h-4 w-4" />
                </button>
                <span className="w-6 text-center text-sm">{qty}</span>
                <button aria-label="Increase quantity" onClick={() => setQty((q) => q + 1)}>
                  <Plus className="h-4 w-4" />
                </button>
              </div>
              <button
                disabled={!product.inStock}
                onClick={add}
                className="inline-flex flex-1 items-center justify-center gap-2 rounded-sm bg-accent px-8 py-4 wordmark text-[11px] text-accent-foreground transition-transform hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-40 sm:flex-none"
              >
                <ShoppingBag className="h-4 w-4" />
                {product.inStock ? "Add to cart" : "Sold out"}
              </button>
            </div>

            <p className="mt-6 text-xs text-muted-foreground">
              Free delivery within Lagos. Worldwide shipping quoted at checkout.
            </p>
          </div>
        </div>
      </div>

      <VideoModal
        open={video}
        onClose={() => setVideo(false)}
        url={product.video ?? ""}
        file={product.videoFile ?? ""}
        title={product.name}
      />

      <Modal open={added} onClose={() => setAdded(false)} label="Added to cart">
        <p className="wordmark text-[10px] text-accent">Added to cart</p>
        <h3 className="mt-2 text-xl">
          {qty} × {product.name}
        </h3>
        <p className="mt-2 text-sm text-muted-foreground">What would you like to do next?</p>
        <div className="mt-6 grid gap-3 sm:grid-cols-2">
          <button
            onClick={() => navigate({ to: "/cart" })}
            className="rounded-sm bg-accent px-5 py-3 wordmark text-[10px] text-accent-foreground"
          >
            Go to cart
          </button>
          <button
            onClick={() => setAdded(false)}
            className="rounded-sm border border-border px-5 py-3 wordmark text-[10px] text-muted-foreground hover:border-accent hover:text-accent"
          >
            Continue shopping
          </button>
        </div>
      </Modal>
    </SiteShell>
  );
}
