import { createFileRoute } from "@tanstack/react-router";
import { SiteShell } from "@/components/SiteShell";
import { useContent } from "@/lib/content";
import { usePageView } from "@/lib/analytics";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Us — Wọ Àrá" },
      {
        name: "description",
        content: "How Wọ Àrá cuts small runs of hand-printed adire and ankara palazzo in Lagos.",
      },
      { property: "og:title", content: "About Us — Wọ Àrá" },
      {
        property: "og:description",
        content: "How Wọ Àrá cuts small runs of hand-printed adire and ankara palazzo in Lagos.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: About,
});

function About() {
  const about = useContent().about;
  usePageView("/about");

  return (
    <SiteShell>
      <section className="px-5 py-16 sm:px-10 lg:px-16 lg:py-24">
        <p className="wordmark text-[11px] text-accent">{about.eyebrow}</p>
        <h1 className="mt-5 max-w-2xl text-4xl leading-tight sm:text-6xl">
          <span className="gold-text">{about.title}</span>
        </h1>
        <div className="mt-12 grid gap-10 lg:grid-cols-[1.1fr_1fr] lg:items-start">
          <div className="grid gap-6 text-sm leading-relaxed text-muted-foreground sm:grid-cols-2">
            {about.body.map((p, i) => (
              <p key={i}>{p}</p>
            ))}
          </div>
          <img
            src={about.image}
            alt="Wọ Àrá studio"
            loading="lazy"
            className="aspect-[4/5] w-full rounded-sm object-cover"
          />
        </div>
      </section>
    </SiteShell>
  );
}
