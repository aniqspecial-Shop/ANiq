import { createFileRoute } from "@tanstack/react-router";
import { SiteShell } from "@/components/SiteShell";
import { useContent } from "@/lib/content";
import { usePageView } from "@/lib/analytics";
import { resolveVideo } from "@/lib/video";

export const Route = createFileRoute("/gallery")({
  head: () => ({
    meta: [
      { title: "Gallery — Wọ Àrá" },
      { name: "description", content: "Wọ Àrá pieces in the studio, on the street and on the people who wear them." },
      { property: "og:title", content: "Gallery — Wọ Àrá" },
      { property: "og:description", content: "Wọ Àrá pieces in the studio and on the street." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Gallery,
});

function Gallery() {
  const gallery = useContent().gallery;
  usePageView("/gallery");
  const hero = resolveVideo(gallery.hero.video, { autoplay: true, muted: true, loop: true });

  return (
    <SiteShell>
      <section className="relative isolate h-[68vh] min-h-[420px] w-full overflow-hidden">
        <div className="absolute inset-0 -z-10">
          {hero.kind === "file" ? (
            <video
              src={hero.src}
              poster={gallery.hero.poster}
              autoPlay
              muted
              loop
              playsInline
              className="h-full w-full object-cover"
            />
          ) : hero.kind === "iframe" ? (
            <iframe
              src={hero.src}
              title={gallery.hero.title}
              allow="autoplay; loop; muted"
              className="pointer-events-none h-full w-full scale-150 object-cover"
            />
          ) : (
            <img src={gallery.hero.poster} alt="" className="h-full w-full animate-slow-zoom object-cover" />
          )}
        </div>
        <div className="absolute inset-0 -z-10 bg-gradient-to-t from-background via-background/60 to-background/20" />

        <div className="flex h-full flex-col justify-end px-5 pb-14 sm:px-10 lg:px-16">
          <h1 className="animate-fade-up text-4xl leading-tight sm:text-6xl">
            <span className="gold-text">{gallery.hero.title}</span>
          </h1>
          <p className="mt-4 max-w-lg animate-fade-up text-sm text-muted-foreground sm:text-base">
            {gallery.hero.subtitle}
          </p>
        </div>
      </section>

      <section className="px-5 py-16 sm:px-10 lg:px-16">
        <p className="wordmark text-[11px] text-accent">Look book</p>
        <h2 className="mt-4 text-3xl sm:text-4xl">{gallery.title}</h2>
        <p className="mt-4 max-w-xl text-sm text-muted-foreground">{gallery.blurb}</p>

        <div className="mt-12 grid gap-6 sm:grid-cols-2 xl:grid-cols-3">
          {gallery.items.map((g) => (
            <figure key={g.id} className="group relative overflow-hidden rounded-sm bg-secondary glow-ring">
              <img
                src={g.image}
                alt={g.caption}
                loading="lazy"
                className="aspect-[3/4] w-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <figcaption className="pointer-events-none absolute inset-0 flex flex-col justify-end bg-gradient-to-t from-background/90 via-background/30 to-transparent p-5 opacity-0 transition-opacity duration-500 group-hover:opacity-100 group-focus-within:opacity-100">
                <p className="wordmark text-[10px] text-accent">{g.caption}</p>
                {g.description && <p className="mt-2 text-xs leading-relaxed text-foreground">{g.description}</p>}
              </figcaption>
            </figure>
          ))}
        </div>
        {gallery.items.length === 0 && (
          <p className="mt-12 text-sm text-muted-foreground">No images yet — add some from the admin.</p>
        )}
      </section>
    </SiteShell>
  );
}
