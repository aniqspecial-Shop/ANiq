import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Plus, Trash2, Lock, LogOut, RotateCcw, Download, Upload } from "lucide-react";
import { SiteShell } from "@/components/SiteShell";
import { ImageField } from "@/components/ImageField";
import { ImagesField } from "@/components/ImagesField";
import { VideoFileField } from "@/components/VideoFileField";
import { Btn, Field, Panel } from "@/components/admin/ui";
import { OrdersTab } from "@/components/admin/OrdersTab";
import { ReportsTab } from "@/components/admin/ReportsTab";
import { ThemeTab } from "@/components/admin/ThemeTab";
import { download, parseCsv, toCsv } from "@/lib/csv";
import {
  hydrateProductDraft,
  importProducts,
  productCsvHeader,
  removeProduct,
  resetProducts,
  sampleProductCsv,
  upsertProduct,
  useAdminProducts,
  useProducts,
  type Product,
} from "@/lib/products";
import { defaultContent, hydrateContentDraft, uid, updateContent, useAdminContent } from "@/lib/content";
import { SaveBar } from "@/components/admin/SaveBar";
import { hydrateAnalytics, sum, useAnalytics } from "@/lib/analytics";
import { hydrateOrders } from "@/lib/orders";
import { adminTokenStore, useAdminToken } from "@/lib/admin-session";
import {
  adminLogin,
  adminLogout,
  clearAnalytics,
  loadAdminState,
  setAdminPassword,
} from "@/lib/shop.functions";
import { usd } from "@/lib/cart";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Studio Admin — Wọ Àrá" },
      { name: "description", content: "Manage Wọ Àrá products, landing page content, ads and settings." },
      { property: "og:title", content: "Studio Admin — Wọ Àrá" },
      { property: "og:description", content: "Manage products, content, ads and settings." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Admin,
});

const TABS = ["Dashboard", "Orders", "Reports", "Products", "Landing Page", "Ads", "Theme & Logo", "Settings"] as const;
type Tab = (typeof TABS)[number];

/* ---------- login ---------- */

function Login({ onOk }: { onOk: () => void }) {
  const [v, setV] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit() {
    setBusy(true);
    try {
      const res = await adminLogin({ data: { password: v } });
      if (!res.ok) {
        setErr("Wrong password.");
        return;
      }
      adminTokenStore.set(res.token);
      onOk();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Could not sign in.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <SiteShell>
      <section className="mx-auto max-w-sm px-5 py-24">
        <p className="wordmark text-[11px] text-accent">Restricted</p>
        <h1 className="mt-4 text-3xl">
          <span className="gold-text">Studio login</span>
        </h1>
        <form
          className="mt-8 space-y-4"
          onSubmit={(e) => {
            e.preventDefault();
            void submit();
          }}
        >
          <Field label="Password" type="password" value={v} onChange={setV} />
          {err && <p className="text-xs text-destructive">{err}</p>}
          <Btn tone="gold" type="submit" disabled={busy}>
            <Lock className="h-3.5 w-3.5" /> {busy ? "Checking…" : "Enter studio"}
          </Btn>
        </form>
      </section>
    </SiteShell>
  );
}

/* ---------- tabs ---------- */

function Dashboard() {
  const a = useAnalytics();
  const products = useProducts();
  const views = sum(a.pageViews);
  const clicks = sum(a.productClicks);
  const adClicks = sum(a.adClicks);

  const stats = [
    { label: "Page views", value: views },
    { label: "Product clicks", value: clicks },
    { label: "Ad clicks", value: adClicks },
    { label: "Add to cart", value: a.addToCart },
    { label: "Checkouts", value: a.checkouts },
    { label: "Live products", value: products.length },
  ];

  return (
    <div className="space-y-6">
      <div className="grid gap-3 sm:grid-cols-3">
        {stats.map((s) => (
          <div key={s.label} className="rounded-sm border border-border bg-card p-5 glow-ring">
            <p className="wordmark text-[10px] text-muted-foreground">{s.label}</p>
            <p className="mt-2 text-3xl text-accent">{s.value}</p>
          </div>
        ))}
      </div>

      <Panel title="Views by page">
        <ul className="space-y-2 text-sm">
          {Object.entries(a.pageViews).length === 0 && (
            <li className="text-muted-foreground">No traffic recorded yet.</li>
          )}
          {Object.entries(a.pageViews)
            .sort((x, y) => y[1] - x[1])
            .map(([k, v]) => (
              <li key={k} className="grid grid-cols-[minmax(0,1fr)_auto] gap-3 border-b border-border pb-2">
                <span className="truncate text-muted-foreground">{k}</span>
                <span className="text-accent">{v}</span>
              </li>
            ))}
        </ul>
      </Panel>

      <Panel title="Product clicks">
        <ul className="space-y-2 text-sm">
          {products.map((p) => (
            <li key={p.id} className="grid grid-cols-[minmax(0,1fr)_auto] gap-3 border-b border-border pb-2">
              <span className="truncate text-muted-foreground">
                {p.name} · {usd(p.price)}
              </span>
              <span className="text-accent">{a.productClicks[p.id] ?? 0}</span>
            </li>
          ))}
        </ul>
      </Panel>

      <Panel
        title="Recent activity"
        action={
          <Btn
            onClick={() => {
              void clearAnalytics({ data: { token: adminTokenStore.get() } });
              hydrateAnalytics([]);
            }}
          >
            <RotateCcw className="h-3 w-3" /> Reset
          </Btn>
        }

      >
        <ul className="space-y-1.5 text-xs">
          {a.events.length === 0 && <li className="text-muted-foreground">Nothing yet.</li>}
          {a.events.slice(0, 20).map((e, i) => (
            <li key={i} className="grid grid-cols-[auto_minmax(0,1fr)_auto] gap-3">
              <span className="wordmark text-[10px] text-accent">{e.type}</span>
              <span className="truncate text-muted-foreground">{e.label}</span>
              <span className="text-muted-foreground">{new Date(e.t).toLocaleTimeString()}</span>
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  );
}

const blank = (): Product => ({
  id: uid(),
  name: "",
  price: 0,
  category: "Palazzo",
  image: "",
  images: [],
  video: "",
  videoFile: "",
  description: "",
  inStock: true,
  vatRate: undefined,
  shippingFee: undefined,
  discountPct: undefined,
});

function ProductsTab() {
  const products = useAdminProducts();
  const [draft, setDraft] = useState<Product | null>(null);

  return (
    <div className="space-y-6">
      <Panel
        title={draft ? (products.some((p) => p.id === draft.id) ? "Edit piece" : "New piece") : "Pieces"}
        action={
          draft ? (
            <Btn onClick={() => setDraft(null)}>Cancel</Btn>
          ) : (
            <Btn tone="gold" onClick={() => setDraft(blank())}>
              <Plus className="h-3 w-3" /> New piece
            </Btn>
          )
        }
      >
        {draft ? (
          <form
            className="space-y-4"
            onSubmit={(e) => {
              e.preventDefault();
              upsertProduct(draft);
              setDraft(null);
            }}
          >
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Name" value={draft.name} onChange={(v) => setDraft({ ...draft, name: v })} />
              <Field
                label="Price (USD)"
                type="number"
                value={draft.price}
                onChange={(v) => setDraft({ ...draft, price: Number(v) || 0 })}
              />
              <Field label="Category" value={draft.category} onChange={(v) => setDraft({ ...draft, category: v })} />
              <label className="flex items-center gap-3 pt-6 text-sm">
                <input
                  type="checkbox"
                  checked={draft.inStock}
                  onChange={(e) => setDraft({ ...draft, inStock: e.target.checked })}
                />
                In stock
              </label>
            </div>
            <ImageField value={draft.image} onChange={(v) => setDraft({ ...draft, image: v })} label="Main product image" />
            <ImagesField
              values={draft.images}
              onChange={(v) => setDraft({ ...draft, images: v })}
              label="Additional images (gallery on the product page)"
            />
            <Field
              label="Preview video link (YouTube, Vimeo, Instagram, TikTok, X, Facebook)"
              value={draft.video}
              onChange={(v) => setDraft({ ...draft, video: v })}
            />
            <VideoFileField
              value={draft.videoFile ?? ""}
              onChange={(v) => setDraft({ ...draft, videoFile: v })}
            />
            <div className="grid gap-4 sm:grid-cols-3">
              <Field
                label="VAT % (blank = store default)"
                value={draft.vatRate ?? ""}
                onChange={(v) => setDraft({ ...draft, vatRate: v === "" ? undefined : Number(v) || 0 })}
              />
              <Field
                label="Extra shipping fee ($)"
                value={draft.shippingFee ?? ""}
                onChange={(v) => setDraft({ ...draft, shippingFee: v === "" ? undefined : Number(v) || 0 })}
              />
              <Field
                label="Discount % on this piece"
                value={draft.discountPct ?? ""}
                onChange={(v) => setDraft({ ...draft, discountPct: v === "" ? undefined : Number(v) || 0 })}
              />
            </div>
            <Field
              label="Description"
              textarea
              value={draft.description}
              onChange={(v) => setDraft({ ...draft, description: v })}
            />
            <Btn tone="gold" type="submit">
              Save piece
            </Btn>
          </form>
        ) : (
          <ul className="space-y-3">
            {products.map((p) => (
              <li
                key={p.id}
                className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-4 rounded-sm border border-border p-3"
              >
                <img src={p.image} alt="" className="h-16 w-14 shrink-0 rounded-sm object-cover" />
                <div className="min-w-0">
                  <p className="truncate text-sm">{p.name}</p>
                  <p className="text-xs text-accent">
                    {usd(p.price)} · {p.category} · {p.inStock ? "In stock" : "Sold"}
                  </p>
                </div>
                <div className="flex shrink-0 gap-2">
                  <Btn onClick={() => setDraft(p)}>Edit</Btn>
                  <Btn tone="danger" onClick={() => removeProduct(p.id)}>
                    <Trash2 className="h-3 w-3" />
                  </Btn>
                </div>
              </li>
            ))}
            {products.length === 0 && <li className="text-sm text-muted-foreground">No pieces yet.</li>}
          </ul>
        )}
      </Panel>

      <ProductCsvPanel />

      <Btn onClick={() => resetProducts()}>
        <RotateCcw className="h-3 w-3" /> Restore default pieces
      </Btn>
    </div>
  );
}

function ProductCsvPanel() {
  const products = useAdminProducts();
  const [msg, setMsg] = useState("");
  const [mode, setMode] = useState<"merge" | "replace">("merge");

  function exportCsv() {
    const rows = [
      productCsvHeader,
      ...products.map((p) => [
        p.id,
        p.name,
        p.price,
        p.category,
        p.image,
        p.images.join("|"),
        p.video,
        p.videoFile ?? "",
        p.description,
        String(p.inStock),
        p.vatRate ?? "",
        p.shippingFee ?? "",
        p.discountPct ?? "",
      ]),
    ];
    download("wo-ara-products.csv", toCsv(rows));
  }

  function importCsv(file?: File | null) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const rows = parseCsv(String(reader.result));
        const head = (rows[0] ?? []).map((h) => h.trim().toLowerCase());
        const idx = (k: string) => head.indexOf(k);
        const num = (v?: string) => (v && v.trim() !== "" ? Number(v) : undefined);
        const list: Product[] = rows.slice(1).map((r) => ({
          id: r[idx("id")]?.trim() || uid(),
          name: r[idx("name")] ?? "Untitled",
          price: Number(r[idx("price")] ?? 0) || 0,
          category: r[idx("category")] ?? "Palazzo",
          image: r[idx("image")] ?? "",
          images: (r[idx("images")] ?? "").split("|").map((x) => x.trim()).filter(Boolean),
          video: r[idx("video")] ?? "",
          videoFile: r[idx("videofile")] ?? "",
          description: r[idx("description")] ?? "",
          inStock: (r[idx("instock")] ?? "true").trim().toLowerCase() !== "false",
          vatRate: num(r[idx("vatrate")]),
          shippingFee: num(r[idx("shippingfee")]),
          discountPct: num(r[idx("discountpct")]),
        }));
        if (!list.length) throw new Error("empty");
        importProducts(list, mode);
        setMsg(`Imported ${list.length} product${list.length === 1 ? "" : "s"}.`);
      } catch {
        setMsg("Could not read that CSV — check it against the sample.");
      }
    };
    reader.readAsText(file);
  }

  return (
    <Panel title="Import / export products">
      <div className="flex flex-wrap gap-2">
        {(["merge", "replace"] as const).map((m) => (
          <button
            key={m}
            onClick={() => setMode(m)}
            className={`rounded-sm px-3 py-1.5 wordmark text-[10px] ${
              mode === m ? "bg-accent text-accent-foreground" : "border border-border text-muted-foreground"
            }`}
          >
            {m === "merge" ? "Merge by id" : "Replace all"}
          </button>
        ))}
      </div>
      <div className="flex flex-wrap gap-2">
        <label className="inline-flex cursor-pointer items-center gap-2 rounded-sm bg-accent px-4 py-2 wordmark text-[10px] text-accent-foreground">
          <Upload className="h-3 w-3" /> Import CSV
          <input type="file" accept=".csv,text/csv" className="hidden" onChange={(e) => importCsv(e.target.files?.[0])} />
        </label>
        <Btn onClick={exportCsv}>
          <Download className="h-3 w-3" /> Export products
        </Btn>
        <Btn onClick={() => download("wo-ara-products-sample.csv", sampleProductCsv)}>
          <Download className="h-3 w-3" /> Sample CSV
        </Btn>
      </div>
      {msg && <p className="text-xs text-accent">{msg}</p>}
      <p className="text-xs text-muted-foreground">
        Columns: {productCsvHeader.join(", ")}. Separate extra images with a pipe (|).
      </p>
    </Panel>
  );
}

function LandingTab() {
  const c = useAdminContent();

  return (
    <div className="space-y-6">
      <Panel
        title="Hero slider"
        action={
          <Btn
            tone="gold"
            onClick={() =>
              updateContent((x) => {
                x.hero.slides.push({
                  id: uid(),
                  image: "",
                  eyebrow: "New slide",
                  title: "Headline",
                  subtitle: "Supporting line",
                  ctaLabel: "Shop now",
                });
                return x;
              })
            }
          >
            <Plus className="h-3 w-3" /> Add slide
          </Btn>
        }
      >
        <Field
          label="Slide interval (ms)"
          type="number"
          value={c.hero.intervalMs}
          onChange={(v) => updateContent((x) => ((x.hero.intervalMs = Number(v) || 5000), x))}
        />
        {c.hero.slides.map((s, i) => (
          <div key={s.id} className="space-y-4 rounded-sm border border-border p-4">
            <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
              <p className="wordmark text-[10px] text-accent">Slide {i + 1}</p>
              <Btn
                tone="danger"
                onClick={() => updateContent((x) => ((x.hero.slides = x.hero.slides.filter((y) => y.id !== s.id)), x))}
              >
                <Trash2 className="h-3 w-3" />
              </Btn>
            </div>
            <ImageField
              value={s.image}
              label="Slide image"
              onChange={(v) =>
                updateContent((x) => {
                  const t = x.hero.slides.find((y) => y.id === s.id);
                  if (t) t.image = v;
                  return x;
                })
              }
            />
            <div className="grid gap-4 sm:grid-cols-2">
              <Field
                label="Eyebrow"
                value={s.eyebrow}
                onChange={(v) =>
                  updateContent((x) => {
                    const t = x.hero.slides.find((y) => y.id === s.id);
                    if (t) t.eyebrow = v;
                    return x;
                  })
                }
              />
              <Field
                label="CTA label"
                value={s.ctaLabel}
                onChange={(v) =>
                  updateContent((x) => {
                    const t = x.hero.slides.find((y) => y.id === s.id);
                    if (t) t.ctaLabel = v;
                    return x;
                  })
                }
              />
            </div>
            <Field
              label="Title"
              value={s.title}
              onChange={(v) =>
                updateContent((x) => {
                  const t = x.hero.slides.find((y) => y.id === s.id);
                  if (t) t.title = v;
                  return x;
                })
              }
            />
            <Field
              label="Subtitle"
              textarea
              value={s.subtitle}
              onChange={(v) =>
                updateContent((x) => {
                  const t = x.hero.slides.find((y) => y.id === s.id);
                  if (t) t.subtitle = v;
                  return x;
                })
              }
            />
          </div>
        ))}
      </Panel>

      <Panel title="Collection section">
        <Field
          label="Title"
          value={c.collection.title}
          onChange={(v) => updateContent((x) => ((x.collection.title = v), x))}
        />
        <Field
          label="Blurb"
          textarea
          value={c.collection.blurb}
          onChange={(v) => updateContent((x) => ((x.collection.blurb = v), x))}
        />
      </Panel>

      <Panel
        title="About Us"
        action={
          <Btn onClick={() => updateContent((x) => ((x.about.body = [...x.about.body, "New paragraph"]), x))}>
            <Plus className="h-3 w-3" /> Paragraph
          </Btn>
        }
      >
        <Field label="Eyebrow" value={c.about.eyebrow} onChange={(v) => updateContent((x) => ((x.about.eyebrow = v), x))} />
        <Field label="Title" value={c.about.title} onChange={(v) => updateContent((x) => ((x.about.title = v), x))} />
        <ImageField
          value={c.about.image}
          label="About image"
          onChange={(v) => updateContent((x) => ((x.about.image = v), x))}
        />
        {c.about.body.map((p, i) => (
          <div key={i} className="grid grid-cols-[minmax(0,1fr)_auto] items-end gap-3">
            <Field
              label={`Paragraph ${i + 1}`}
              textarea
              value={p}
              onChange={(v) => updateContent((x) => ((x.about.body[i] = v), x))}
            />
            <Btn tone="danger" onClick={() => updateContent((x) => ((x.about.body = x.about.body.filter((_, j) => j !== i)), x))}>
              <Trash2 className="h-3 w-3" />
            </Btn>
          </div>
        ))}
      </Panel>

      <Panel
        title="Gallery"
        action={
          <Btn
            tone="gold"
            onClick={() => updateContent((x) => ((x.gallery.items = [...x.gallery.items, { id: uid(), image: "", caption: "New image", description: "" }]), x))}
          >
            <Plus className="h-3 w-3" /> Add image
          </Btn>
        }
      >
        <div className="space-y-4 rounded-sm border border-accent/30 p-4">
          <p className="wordmark text-[10px] text-accent">Gallery hero video</p>
          <Field
            label="Video URL (mp4, YouTube, Instagram, TikTok, X, Vimeo…)"
            value={c.gallery.hero.video}
            onChange={(v) => updateContent((x) => ((x.gallery.hero.video = v), x))}
          />
          <ImageField
            label="Poster / fallback image"
            value={c.gallery.hero.poster}
            onChange={(v) => updateContent((x) => ((x.gallery.hero.poster = v), x))}
          />
          <Field
            label="Hero title"
            value={c.gallery.hero.title}
            onChange={(v) => updateContent((x) => ((x.gallery.hero.title = v), x))}
          />
          <Field
            label="Hero subtitle"
            value={c.gallery.hero.subtitle}
            onChange={(v) => updateContent((x) => ((x.gallery.hero.subtitle = v), x))}
          />
        </div>
        <Field label="Title" value={c.gallery.title} onChange={(v) => updateContent((x) => ((x.gallery.title = v), x))} />
        <Field
          label="Blurb"
          textarea
          value={c.gallery.blurb}
          onChange={(v) => updateContent((x) => ((x.gallery.blurb = v), x))}
        />
        {c.gallery.items.map((g) => (
          <div key={g.id} className="space-y-3 rounded-sm border border-border p-4">
            <ImageField
              value={g.image}
              label="Gallery image"
              onChange={(v) =>
                updateContent((x) => {
                  const t = x.gallery.items.find((y) => y.id === g.id);
                  if (t) t.image = v;
                  return x;
                })
              }
            />
            <div className="grid grid-cols-[minmax(0,1fr)_auto] items-end gap-3">
              <Field
                label="Caption"
                value={g.caption}
                onChange={(v) =>
                  updateContent((x) => {
                    const t = x.gallery.items.find((y) => y.id === g.id);
                    if (t) t.caption = v;
                    return x;
                  })
                }
              />
              <Btn
                tone="danger"
                onClick={() => updateContent((x) => ((x.gallery.items = x.gallery.items.filter((y) => y.id !== g.id)), x))}
              >
                <Trash2 className="h-3 w-3" />
              </Btn>
            </div>
            <Field
              label="Hover description"
              textarea
              value={g.description}
              onChange={(v) =>
                updateContent((x) => {
                  const t = x.gallery.items.find((y) => y.id === g.id);
                  if (t) t.description = v;
                  return x;
                })
              }
            />
          </div>
        ))}
      </Panel>

      <Panel title="Contact Us">
        <Field label="Title" value={c.contact.title} onChange={(v) => updateContent((x) => ((x.contact.title = v), x))} />
        <Field
          label="Blurb"
          textarea
          value={c.contact.blurb}
          onChange={(v) => updateContent((x) => ((x.contact.blurb = v), x))}
        />
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Email" value={c.contact.email} onChange={(v) => updateContent((x) => ((x.contact.email = v), x))} />
          <Field label="Phone" value={c.contact.phone} onChange={(v) => updateContent((x) => ((x.contact.phone = v), x))} />
          <Field label="Address" value={c.contact.address} onChange={(v) => updateContent((x) => ((x.contact.address = v), x))} />
          <Field
            label="Instagram URL"
            value={c.contact.instagram}
            onChange={(v) => updateContent((x) => ((x.contact.instagram = v), x))}
          />
        </div>
      </Panel>
    </div>
  );
}

function AdsTab() {
  const ads = useAdminContent().ads;
  return (
    <Panel
      title="Ad banners"
      action={
        <Btn
          tone="gold"
          onClick={() =>
            updateContent((x) => {
              x.ads.push({
                id: uid(),
                active: true,
                image: "",
                title: "New promotion",
                text: "Describe the offer",
                ctaLabel: "Shop now",
                ctaUrl: "/",
              });
              return x;
            })
          }
        >
          <Plus className="h-3 w-3" /> New ad
        </Btn>
      }
    >
      {ads.length === 0 && <p className="text-sm text-muted-foreground">No ads yet.</p>}
      {ads.map((ad) => (
        <div key={ad.id} className="space-y-4 rounded-sm border border-border p-4">
          <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
            <label className="flex items-center gap-3 text-sm">
              <input
                type="checkbox"
                checked={ad.active}
                onChange={(e) =>
                  updateContent((x) => {
                    const t = x.ads.find((y) => y.id === ad.id);
                    if (t) t.active = e.target.checked;
                    return x;
                  })
                }
              />
              Active on every page
            </label>
            <Btn tone="danger" onClick={() => updateContent((x) => ((x.ads = x.ads.filter((y) => y.id !== ad.id)), x))}>
              <Trash2 className="h-3 w-3" />
            </Btn>
          </div>
          <ImageField
            value={ad.image}
            label="Ad image"
            onChange={(v) =>
              updateContent((x) => {
                const t = x.ads.find((y) => y.id === ad.id);
                if (t) t.image = v;
                return x;
              })
            }
          />
          <div className="grid gap-4 sm:grid-cols-2">
            <Field
              label="Title"
              value={ad.title}
              onChange={(v) =>
                updateContent((x) => {
                  const t = x.ads.find((y) => y.id === ad.id);
                  if (t) t.title = v;
                  return x;
                })
              }
            />
            <Field
              label="CTA label"
              value={ad.ctaLabel}
              onChange={(v) =>
                updateContent((x) => {
                  const t = x.ads.find((y) => y.id === ad.id);
                  if (t) t.ctaLabel = v;
                  return x;
                })
              }
            />
          </div>
          <Field
            label="Text"
            value={ad.text}
            onChange={(v) =>
              updateContent((x) => {
                const t = x.ads.find((y) => y.id === ad.id);
                if (t) t.text = v;
                return x;
              })
            }
          />
          <Field
            label="CTA link"
            value={ad.ctaUrl}
            onChange={(v) =>
              updateContent((x) => {
                const t = x.ads.find((y) => y.id === ad.id);
                if (t) t.ctaUrl = v;
                return x;
              })
            }
          />
        </div>
      ))}
    </Panel>
  );
}

function CheckoutPanel() {
  const c = useAdminContent().checkout;
  return (
    <Panel title="Checkout charges">
      <div className="grid gap-4 sm:grid-cols-2">
        <Field
          label="VAT %"
          type="number"
          value={c.vatRate}
          onChange={(v) => updateContent((x) => ((x.checkout.vatRate = Number(v) || 0), x))}
        />
        <Field
          label="Flat shipping fee ($)"
          type="number"
          value={c.shippingFee}
          onChange={(v) => updateContent((x) => ((x.checkout.shippingFee = Number(v) || 0), x))}
        />
        <Field
          label="Free shipping over ($, 0 = never)"
          type="number"
          value={c.freeShippingOver}
          onChange={(v) => updateContent((x) => ((x.checkout.freeShippingOver = Number(v) || 0), x))}
        />
        <Field
          label="Store-wide discount %"
          type="number"
          value={c.discountPct}
          onChange={(v) => updateContent((x) => ((x.checkout.discountPct = Number(v) || 0), x))}
        />
        <Field
          label="Coupon code"
          value={c.couponCode}
          onChange={(v) => updateContent((x) => ((x.checkout.couponCode = v), x))}
        />
        <Field
          label="Coupon discount %"
          type="number"
          value={c.couponPct}
          onChange={(v) => updateContent((x) => ((x.checkout.couponPct = Number(v) || 0), x))}
        />
      </div>
    </Panel>
  );
}

function SettingsTab() {
  const s = useAdminContent().settings;
  return (
    <div className="space-y-6">
      <Panel title="Store settings">
        <Field
          label="WhatsApp number (checkout)"
          value={s.whatsapp}
          onChange={(v) => updateContent((x) => ((x.settings.whatsapp = v), x))}
        />
        <Field
          label="Checkout message"
          textarea
          value={s.checkoutMessage}
          onChange={(v) => updateContent((x) => ((x.settings.checkoutMessage = v), x))}
        />
        <Field
          label="Naira per $1"
          type="number"
          value={s.ngnRate}
          onChange={(v) => updateContent((x) => ((x.settings.ngnRate = Number(v) || 0), x))}
        />
        <Field label="Sidebar tagline" value={s.tagline} onChange={(v) => updateContent((x) => ((x.settings.tagline = v), x))} />
        <AdminPasswordField />

      </Panel>
      <CheckoutPanel />
      <Btn tone="danger" onClick={() => updateContent(() => structuredClone(defaultContent))}>
        <RotateCcw className="h-3 w-3" /> Reset all landing page content
      </Btn>
    </div>
  );
}

/* ---------- shell ---------- */

/** Password changes apply immediately and are stored outside public content. */
function AdminPasswordField() {
  const [v, setV] = useState("");
  const [msg, setMsg] = useState("");

  async function apply() {
    const res = await setAdminPassword({ data: { token: adminTokenStore.get(), password: v } });
    setMsg(res.ok ? "Admin password updated." : (res.error ?? "Could not update."));
    if (res.ok) setV("");
  }

  return (
    <div className="space-y-2">
      <Field label="New admin password" type="password" value={v} onChange={setV} />
      <div className="flex items-center gap-3">
        <Btn onClick={() => void apply()} disabled={!v}>
          <Lock className="h-3 w-3" /> Change password
        </Btn>
        {msg && <span className="text-xs text-muted-foreground">{msg}</span>}
      </div>
    </div>
  );
}

function Admin() {
  const token = useAdminToken();
  const [tab, setTab] = useState<Tab>("Dashboard");
  const [ready, setReady] = useState(false);

  // Pull everything only the admin may see: pending drafts, orders, analytics.
  useEffect(() => {
    if (!token) {
      setReady(false);
      return;
    }
    let live = true;
    void (async () => {
      try {
        const state = await loadAdminState({ data: { token } });
        if (!live) return;
        if (!state.ok) {
          adminTokenStore.set("");
          return;
        }
        hydrateContentDraft(state.contentDraft);
        hydrateProductDraft(state.productDraft);
        hydrateOrders(state.orders);
        hydrateAnalytics(state.events);
        setReady(true);
      } catch {
        if (live) adminTokenStore.set("");
      }
    })();
    return () => {
      live = false;
    };
  }, [token]);

  if (!token) return <Login onOk={() => undefined} />;

  return (
    <SiteShell>
      <section className="px-5 py-12 sm:px-10 lg:px-16">
        <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4">
          <div className="min-w-0">
            <p className="wordmark text-[11px] text-accent">Studio</p>
            <h1 className="mt-3 text-3xl sm:text-4xl">
              <span className="gold-text">Admin</span>
            </h1>
            {!ready && <p className="mt-2 text-xs text-muted-foreground">Loading studio data…</p>}
          </div>
          <Btn
            onClick={() => {
              void adminLogout({ data: { token } });
              adminTokenStore.set("");
            }}
          >
            <LogOut className="h-3 w-3" /> Log out
          </Btn>
        </div>


        <div className="mt-8 flex flex-wrap gap-2 border-b border-border pb-3">
          {TABS.map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`rounded-sm px-4 py-2 wordmark text-[10px] transition-colors ${
                tab === t ? "bg-accent text-accent-foreground" : "border border-border text-muted-foreground hover:text-accent"
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        <div className="mt-8 max-w-5xl">
          {tab === "Dashboard" && <Dashboard />}
          {tab === "Orders" && <OrdersTab />}
          {tab === "Reports" && <ReportsTab />}
          {tab === "Theme & Logo" && <ThemeTab />}
          {tab === "Products" && <ProductsTab />}
          {tab === "Landing Page" && <LandingTab />}
          {tab === "Ads" && <AdsTab />}
          {tab === "Settings" && <SettingsTab />}
        </div>

        <div className="h-28" aria-hidden />
        <SaveBar />
      </section>
    </SiteShell>
  );
}
