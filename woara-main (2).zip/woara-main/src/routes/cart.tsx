import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Minus, Plus, Trash2, MessageCircle } from "lucide-react";
import { SiteShell } from "@/components/SiteShell";
import { cartTotal, clearCart, computeCharges, ngn, removeLine, setQty, usd, useCart } from "@/lib/cart";
import { useContent } from "@/lib/content";
import { createOrder } from "@/lib/orders";
import { trackCheckout, usePageView } from "@/lib/analytics";

export const Route = createFileRoute("/cart")({
  head: () => ({
    meta: [
      { title: "Your Cart — Wọ Àrá" },
      { name: "description", content: "Review your Wọ Àrá selection in USD and Naira, then pay over WhatsApp." },
      { property: "og:title", content: "Your Cart — Wọ Àrá" },
      { property: "og:description", content: "Review your selection and check out over WhatsApp." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: CartPage,
});

function CartPage() {
  const lines = useCart();
  const { settings, checkout } = useContent();
  const [code, setCode] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [note, setNote] = useState("");
  const [err, setErr] = useState("");
  usePageView("/cart");

  const charges = computeCharges(lines, checkout, code);
  const naira = charges.total * settings.ngnRate;
  const couponOk =
    code.trim() !== "" && code.trim().toUpperCase() === checkout.couponCode.trim().toUpperCase();

  function pay() {
    if (!lines.length) return;
    if (!name.trim() || !phone.trim()) {
      setErr("Add your name and phone number so we can track the order.");
      return;
    }
    setErr("");

    const order = createOrder({
      name: name.trim(),
      phone: phone.trim(),
      note: note.trim(),
      items: lines.map((l) => ({ id: l.id, name: l.name, price: l.price, qty: l.qty, image: l.image })),
      subtotal: charges.subtotal,
      discount: charges.discount,
      vat: charges.vat,
      shipping: charges.shipping,
      total: charges.total,
      ngnRate: settings.ngnRate,
    });

    const origin = typeof window !== "undefined" ? window.location.origin : "";
    const imageLink = (src: string) => {
      if (!src) return "";
      if (/^https?:\/\//i.test(src)) return src;
      if (src.startsWith("/")) return origin ? `${origin}${src}` : "";
      return "";
    };

    const body = lines
      .map((l) => {
        const link = imageLink(l.image);
        return [`• ${l.name} × ${l.qty} — ${usd(l.price * l.qty)}`, link ? `  ${link}` : ""]
          .filter(Boolean)
          .join("\n");
      })
      .join("\n");
    // WhatsApp only previews the first link in a message, so lead with a product photo.
    const previewLink = lines.map((l) => imageLink(l.image)).find(Boolean) ?? "";
    const msg = [
      previewLink,
      settings.checkoutMessage,
      "",
      `Order ref: ${order.ref}`,
      `Name: ${order.name}`,
      `Phone: ${order.phone}`,
      "",
      body,
      "",
      `Subtotal: ${usd(charges.subtotal)}`,
      charges.discount > 0 ? `Discount: -${usd(charges.discount)}` : "",
      charges.vat > 0 ? `VAT: ${usd(charges.vat)}` : "",
      `Shipping: ${charges.shipping === 0 ? "Free" : usd(charges.shipping)}`,
      `Total: ${usd(charges.total)} (${ngn(naira)})`,
      note.trim() ? `Note: ${note.trim()}` : "",
    ]
      .filter(Boolean)
      .join("\n");

    trackCheckout(usd(charges.total));
    window.open(
      `https://wa.me/${settings.whatsapp.replace(/\D/g, "")}?text=${encodeURIComponent(msg)}`,
      "_blank",
      "noopener",
    );
    clearCart();
  }

  return (
    <SiteShell>
      <section className="px-5 py-14 sm:px-10 lg:px-16">
        <p className="wordmark text-[11px] text-accent">Your selection</p>
        <h1 className="mt-4 text-4xl sm:text-5xl">
          <span className="gold-text">Cart</span>
        </h1>

        {lines.length === 0 ? (
          <p className="mt-10 text-sm text-muted-foreground">
            Your cart is empty.{" "}
            <Link to="/" className="hairline-link text-accent">
              Browse the collection
            </Link>
            .
          </p>
        ) : (
          <div className="mt-10 grid gap-10 lg:grid-cols-[1.4fr_1fr] lg:items-start">
            <div className="space-y-8">
              <ul className="space-y-4">
                {lines.map((l) => (
                  <li
                    key={l.id}
                    className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-4 rounded-sm border border-border bg-card p-4"
                  >
                    <img src={l.image} alt={l.name} className="h-20 w-16 shrink-0 rounded-sm object-cover" />
                    <div className="min-w-0">
                      <p className="truncate text-sm">{l.name}</p>
                      <p className="mt-1 text-xs text-accent">{usd(l.price)}</p>
                      <div className="mt-3 inline-flex items-center gap-3 rounded-sm border border-border px-2 py-1">
                        <button aria-label="Decrease" onClick={() => setQty(l.id, l.qty - 1)}>
                          <Minus className="h-3.5 w-3.5" />
                        </button>
                        <span className="w-6 text-center text-sm">{l.qty}</span>
                        <button aria-label="Increase" onClick={() => setQty(l.id, l.qty + 1)}>
                          <Plus className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                    <div className="shrink-0 text-right">
                      <p className="text-sm">{usd(l.price * l.qty)}</p>
                      <button
                        onClick={() => removeLine(l.id)}
                        className="mt-3 text-muted-foreground hover:text-destructive"
                        aria-label={`Remove ${l.name}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </li>
                ))}
              </ul>

              <div className="rounded-sm border border-border bg-card p-5">
                <h2 className="text-lg">Your details</h2>
                <div className="mt-4 grid gap-4 sm:grid-cols-2">
                  <Input label="Full name" value={name} onChange={setName} />
                  <Input label="Phone number" value={phone} onChange={setPhone} />
                </div>
                <div className="mt-4">
                  <Input label="Delivery note (optional)" value={note} onChange={setNote} />
                </div>
              </div>
            </div>

            <aside className="rounded-sm border border-accent/30 bg-card p-6 glow-ring">
              <h2 className="text-xl">Order summary</h2>

              <div className="mt-5">
                <Input label={`Discount code`} value={code} onChange={setCode} />
                {code.trim() !== "" && (
                  <p className={`mt-2 text-[11px] ${couponOk ? "text-emerald-400" : "text-muted-foreground"}`}>
                    {couponOk ? `Code applied — ${checkout.couponPct}% off.` : "That code isn't recognised."}
                  </p>
                )}
              </div>

              <dl className="mt-6 space-y-3 text-sm">
                <Line k="Subtotal" v={usd(charges.subtotal)} />
                {charges.discount > 0 && <Line k="Discount" v={`- ${usd(charges.discount)}`} />}
                {charges.vat > 0 && <Line k={`VAT (${checkout.vatRate}%)`} v={usd(charges.vat)} />}
                <Line k="Shipping" v={charges.shipping === 0 ? "Free" : usd(charges.shipping)} />
                <div className="flex items-baseline justify-between border-t border-border pt-3">
                  <dt className="text-muted-foreground">Total (USD)</dt>
                  <dd className="text-lg text-accent">{usd(charges.total)}</dd>
                </div>
                <Line k="Total (NGN)" v={ngn(naira)} />
                <p className="text-[11px] text-muted-foreground">
                  Converted at ₦{settings.ngnRate.toLocaleString()} / $1. Cart value {usd(cartTotal(lines))}.
                </p>
              </dl>

              {err && <p className="mt-4 text-xs text-destructive">{err}</p>}

              <button
                onClick={pay}
                className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-sm bg-accent px-8 py-4 wordmark text-[11px] text-accent-foreground transition-transform hover:-translate-y-0.5"
              >
                <MessageCircle className="h-4 w-4" /> Pay on WhatsApp
              </button>
              <p className="mt-3 text-[11px] text-muted-foreground">
                Creates an order for approval, sends your selection to {settings.whatsapp} and clears the cart.
              </p>
            </aside>
          </div>
        )}
      </section>
    </SiteShell>
  );
}

function Line({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex items-baseline justify-between">
      <dt className="text-muted-foreground">{k}</dt>
      <dd>{v}</dd>
    </div>
  );
}

function Input({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <label className="block space-y-1.5">
      <span className="wordmark text-[10px] text-muted-foreground">{label}</span>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-sm border border-border bg-background px-3 py-2 text-sm outline-none focus:border-accent"
      />
    </label>
  );
}
