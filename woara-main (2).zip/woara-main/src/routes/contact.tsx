import { createFileRoute } from "@tanstack/react-router";
import { Mail, Phone, MapPin, Instagram, MessageCircle } from "lucide-react";
import { SiteShell } from "@/components/SiteShell";
import { useContent } from "@/lib/content";
import { usePageView } from "@/lib/analytics";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact Us — Wọ Àrá" },
      { name: "description", content: "Reach the Wọ Àrá studio for sizing, shipping or a custom cut." },
      { property: "og:title", content: "Contact Us — Wọ Àrá" },
      { property: "og:description", content: "Reach the Wọ Àrá studio in Lagos." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Contact,
});

function Contact() {
  const { contact, settings } = useContent();
  usePageView("/contact");

  const wa = `https://wa.me/${settings.whatsapp.replace(/\D/g, "")}`;

  return (
    <SiteShell>
      <section className="px-5 py-16 sm:px-10 lg:px-16">
        <p className="wordmark text-[11px] text-accent">Say hello</p>
        <h1 className="mt-4 text-4xl sm:text-5xl">
          <span className="gold-text">{contact.title}</span>
        </h1>
        <p className="mt-4 max-w-xl text-sm text-muted-foreground">{contact.blurb}</p>

        <div className="mt-12 grid max-w-3xl gap-4 sm:grid-cols-2">
          <a
            href={`mailto:${contact.email}`}
            className="grid grid-cols-[auto_minmax(0,1fr)] items-center gap-3 rounded-sm border border-border bg-card p-5 hover:border-accent"
          >
            <Mail className="h-4 w-4 shrink-0 text-accent" />
            <span className="min-w-0 truncate text-sm">{contact.email}</span>
          </a>
          <a
            href={`tel:${contact.phone}`}
            className="grid grid-cols-[auto_minmax(0,1fr)] items-center gap-3 rounded-sm border border-border bg-card p-5 hover:border-accent"
          >
            <Phone className="h-4 w-4 shrink-0 text-accent" />
            <span className="min-w-0 truncate text-sm">{contact.phone}</span>
          </a>
          <div className="grid grid-cols-[auto_minmax(0,1fr)] items-center gap-3 rounded-sm border border-border bg-card p-5">
            <MapPin className="h-4 w-4 shrink-0 text-accent" />
            <span className="min-w-0 truncate text-sm">{contact.address}</span>
          </div>
          <a
            href={contact.instagram}
            target="_blank"
            rel="noreferrer"
            className="grid grid-cols-[auto_minmax(0,1fr)] items-center gap-3 rounded-sm border border-border bg-card p-5 hover:border-accent"
          >
            <Instagram className="h-4 w-4 shrink-0 text-accent" />
            <span className="min-w-0 truncate text-sm">Instagram</span>
          </a>
        </div>

        <a
          href={wa}
          target="_blank"
          rel="noreferrer"
          className="mt-8 inline-flex items-center gap-2 rounded-sm bg-accent px-8 py-4 wordmark text-[11px] text-accent-foreground transition-transform hover:-translate-y-0.5"
        >
          <MessageCircle className="h-4 w-4" /> Chat on WhatsApp
        </a>
      </section>
    </SiteShell>
  );
}
