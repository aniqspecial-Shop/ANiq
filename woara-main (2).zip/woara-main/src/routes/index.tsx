import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { PlayCircle } from "lucide-react";
import { SiteShell } from "@/components/SiteShell";
import { VideoModal } from "@/components/Modal";
import { HeroSlider } from "@/components/HeroSlider";
import { formatPrice, useProducts } from "@/lib/products";
import { useContent } from "@/lib/content";
import { trackProductClick, usePageView } from "@/lib/analytics";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Wọ Àrá — Hand-printed Adire & Ankara Palazzo" },
      {
        name: "description",
        content:
          "Small-run palazzo trousers in hand-printed adire and ankara, cut in Lagos. Shop the current drop.",
      },
      { property: "og:title", content: "Wọ Àrá — Hand-printed Adire & Ankara Palazzo" },
      {
        property: "og:description",
        content: "Small-run palazzo trousers in hand-printed adire and ankara, cut in Lagos.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Shop,
});

function Shop() {
  const products = useProducts();
  const content = useContent();
  const [preview, setPreview] = useState<{ url: string; file: string; title: string } | null>(null);
  usePageView("/");

  return (
    <SiteShell>
      <HeroSlider />

      <section id="collection" className="px-5 py-14 sm:px-10 lg:px-16">
        <div className="grid grid-cols-[minmax(0,1fr)_auto] items-end gap-4 border-b border-border pb-4">
          <div className="min-w-0">
            <h2 className="truncate text-2xl sm:text-3xl">{content.collection.title}</h2>
            <p className="mt-2 max-w-xl text-xs text-muted-foreground">{content.collection.blurb}</p>
          </div>
          <span className="shrink-0 wordmark text-[11px] text-accent">
            {products.length} piece{products.length === 1 ? "" : "s"}
          </span>
        </div>

        <div className="mt-10 grid gap-x-8 gap-y-14 sm:grid-cols-2 xl:grid-cols-3">
          {products.map((p) => (
            <Link
              key={p.id}
              to="/product/$id"
              params={{ id: p.id }}
              onClick={() => trackProductClick(p.id)}
              className="group block"
            >
              <div className="relative overflow-hidden rounded-sm bg-secondary glow-ring">
                <img
                  src={p.image}
                  alt={p.name}
                  loading="lazy"
                  className="aspect-[3/4] w-full object-cover transition-transform duration-700 group-hover:scale-[1.05]"
                />
                <button
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    setPreview({ url: p.video ?? "", file: p.videoFile ?? "", title: p.name });
                  }}
                  className="absolute inset-x-3 bottom-3 grid grid-cols-[auto_minmax(0,1fr)] items-center gap-3 rounded-sm border border-accent/40 bg-background/80 p-3 text-left opacity-100 backdrop-blur transition-all duration-500 sm:opacity-0 group-hover:opacity-100 focus:opacity-100"
                >
                  <PlayCircle className="h-5 w-5 shrink-0 text-accent" />
                  <span className="min-w-0">
                    <span className="block wordmark text-[9px] text-accent">Preview dress</span>
                    <span className="block truncate text-[11px] text-muted-foreground">Watch it move</span>
                  </span>
                </button>
                {!p.inStock && (
                  <span className="absolute left-4 top-4 wordmark rounded-sm bg-primary px-3 py-1 text-[10px] text-primary-foreground">
                    Sold
                  </span>
                )}
              </div>
              <div className="mt-4 grid grid-cols-[minmax(0,1fr)_auto] items-baseline gap-3">
                <h3 className="truncate text-lg group-hover:text-accent">{p.name}</h3>
                <span className="shrink-0 text-sm text-accent">{formatPrice(p.price)}</span>
              </div>
              <p className="mt-1 wordmark text-[10px] text-muted-foreground">{p.category}</p>
            </Link>
          ))}
        </div>

        {products.length === 0 && (
          <p className="mt-16 text-sm text-muted-foreground">
            No pieces published yet. Add one from the{" "}
            <Link to="/admin" className="hairline-link text-accent">
              admin
            </Link>
            .
          </p>
        )}
      </section>

      <section className="border-t border-border px-5 py-16 sm:px-10 lg:px-16">
        <div className="grid gap-10 lg:grid-cols-2 lg:items-center">
          <img
            src={content.about.image}
            alt="Inside the Wọ Àrá studio"
            loading="lazy"
            className="aspect-[4/3] w-full rounded-sm object-cover"
          />
          <div>
            <p className="wordmark text-[11px] text-accent">{content.about.eyebrow}</p>
            <h2 className="mt-4 text-3xl sm:text-4xl">{content.about.title}</h2>
            {content.about.body.map((para, i) => (
              <p key={i} className="mt-4 max-w-xl text-sm leading-relaxed text-muted-foreground">
                {para}
              </p>
            ))}
            <Link to="/about" className="mt-8 inline-block hairline-link wordmark text-[11px] text-accent">
              Read more
            </Link>
          </div>
        </div>
      </section>

      <VideoModal
        open={preview !== null}
        onClose={() => setPreview(null)}
        url={preview?.url ?? ""}
        file={preview?.file ?? ""}
        title={preview?.title ?? "Preview"}
      />
    </SiteShell>
  );
}
