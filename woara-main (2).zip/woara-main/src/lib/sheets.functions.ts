import { createServerFn } from "@tanstack/react-start";

export type SheetPayload = { title: string; rows: (string | number)[][] };

const GATEWAY = "https://connector-gateway.lovable.dev/google_sheets/v4";

type Input = { spreadsheetId?: string; title?: string; sheets: SheetPayload[] };

function validate(data: unknown): Input {
  const d = data as Input;
  if (!d || !Array.isArray(d.sheets) || d.sheets.length === 0) throw new Error("No data to sync.");
  return {
    spreadsheetId: typeof d.spreadsheetId === "string" ? d.spreadsheetId.trim() : "",
    title: typeof d.title === "string" ? d.title : "Wọ Àrá Reports",
    sheets: d.sheets.map((s) => ({ title: String(s.title), rows: Array.isArray(s.rows) ? s.rows : [] })),
  };
}

/** Accepts a full Google Sheets URL or a bare id. */
function normalizeId(raw: string) {
  const m = raw.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
  return m?.[1] ?? raw;
}

export const syncReportsToSheets = createServerFn({ method: "POST" })
  .inputValidator(validate)
  .handler(async ({ data }) => {
    const lovableKey = process.env["LOVABLE_API_KEY"];
    const connectionKey = process.env["GOOGLE_SHEETS_API_KEY"];
    if (!lovableKey || !connectionKey) throw new Error("Google Sheets is not connected for this project.");

    const headers = {
      Authorization: `Bearer ${lovableKey}`,
      "X-Connection-Api-Key": connectionKey,
      "Content-Type": "application/json",
    };

    async function call(path: string, init?: { method?: string; body?: unknown }) {
      const res = await fetch(`${GATEWAY}${path}`, {
        method: init?.method ?? "GET",
        headers,
        ...(init?.body ? { body: JSON.stringify(init.body) } : {}),
      });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(`Google Sheets request failed [${res.status}]: ${text}`);
      }
      return (await res.json()) as Record<string, unknown>;
    }

    let spreadsheetId = data.spreadsheetId ? normalizeId(data.spreadsheetId) : "";

    if (!spreadsheetId) {
      const created = await call("/spreadsheets", {
        method: "POST",
        body: {
          properties: { title: data.title },
          sheets: data.sheets.map((s) => ({ properties: { title: s.title } })),
        },
      });
      spreadsheetId = String(created["spreadsheetId"]);
    } else {
      const meta = (await call(`/spreadsheets/${spreadsheetId}`)) as {
        sheets?: { properties?: { title?: string } }[];
      };
      const existing = new Set((meta.sheets ?? []).map((s) => s.properties?.title));
      const missing = data.sheets.filter((s) => !existing.has(s.title));
      if (missing.length) {
        await call(`/spreadsheets/${spreadsheetId}:batchUpdate`, {
          method: "POST",
          body: { requests: missing.map((s) => ({ addSheet: { properties: { title: s.title } } })) },
        });
      }
      await call(`/spreadsheets/${spreadsheetId}/values:batchClear`, {
        method: "POST",
        body: { ranges: data.sheets.map((s) => `${s.title}!A1:ZZ50000`) },
      });
    }

    await call(`/spreadsheets/${spreadsheetId}/values:batchUpdate`, {
      method: "POST",
      body: {
        valueInputOption: "USER_ENTERED",
        data: data.sheets.map((s) => ({ range: `${s.title}!A1`, values: s.rows })),
      },
    });

    return {
      spreadsheetId,
      url: `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`,
      syncedAt: Date.now(),
      tabs: data.sheets.map((s) => `${s.title} (${Math.max(0, s.rows.length - 1)})`),
    };
  });
