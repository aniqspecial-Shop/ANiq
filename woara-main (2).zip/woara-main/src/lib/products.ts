import { supabase } from "@/integrations/supabase/client";
import { createLiveStore, createMemoryStore, debounce } from "./live";
import { adminToken } from "./admin-session";
import { saveDraft } from "./shop.functions";
import p1 from "@/assets/p1.png.asset.json";
import p2 from "@/assets/p2.png.asset.json";
import p3 from "@/assets/p3.png.asset.json";
import p4 from "@/assets/p4.png.asset.json";

export type Product = {
  id: string;
  name: string;
  price: number;
  category: string;
  image: string;
  images: string[];
  video: string;
  videoFile?: string;
  description: string;
  inStock: boolean;
  vatRate?: number | undefined;
  shippingFee?: number | undefined;
  discountPct?: number | undefined;
};

/** Only used as the CSV/reset template — the shop itself reads the database. */
export const seedProducts: Product[] = [
  {
    id: "p1",
    name: "Charcoal Brushstroke Palazzo",
    price: 120,
    category: "Palazzo",
    image: p1.url,
    images: [p1.url, p3.url],
    video: "",
    description:
      "Wide-leg palazzo trousers in a hand-printed charcoal brushstroke adire. Drawstring waist, deep pockets, unlined for breathability.",
    inStock: true,
  },
  {
    id: "p2",
    name: "Amethyst Marble Palazzo",
    price: 135,
    category: "Palazzo",
    image: p2.url,
    images: [p2.url, p4.url],
    video: "",
    description:
      "Purple and gold tie-dye marbling on soft cotton. Elasticated waist with a flowing wide leg that moves with you.",
    inStock: true,
  },
  {
    id: "p3",
    name: "Patchwork Heritage Palazzo",
    price: 180,
    category: "Limited",
    image: p3.url,
    images: [p3.url, p1.url],
    video: "",
    description:
      "A one-of-one patchwork of vintage adire panels — emerald, indigo and ochre stitched into a single statement piece.",
    inStock: true,
  },
  {
    id: "p4",
    name: "Teal Feather Ankara Palazzo",
    price: 145,
    category: "Ankara",
    image: p4.url,
    images: [p4.url, p2.url],
    video: "",
    description:
      "Bold teal and citrine feather-print ankara, cut full through the leg with a relaxed high waist.",
    inStock: true,
  },
];

type Row = {
  id: string;
  name: string;
  price: number | string;
  category: string;
  image: string;
  images: unknown;
  video: string;
  video_file: string | null;
  description: string;
  in_stock: boolean;
  vat_rate: number | string | null;
  shipping_fee: number | string | null;
  discount_pct: number | string | null;
};

const num = (v: unknown) => (v === null || v === undefined || v === "" ? undefined : Number(v));

const fromRow = (r: Row): Product => ({
  id: r.id,
  name: r.name,
  price: Number(r.price) || 0,
  category: r.category,
  image: r.image,
  images: Array.isArray(r.images) ? (r.images as string[]) : [],
  video: r.video ?? "",
  videoFile: r.video_file ?? "",
  description: r.description ?? "",
  inStock: r.in_stock,
  vatRate: num(r.vat_rate),
  shippingFee: num(r.shipping_fee),
  discountPct: num(r.discount_pct),
});

const normalize = (list: Product[]) =>
  list.map((p) => ({
    ...p,
    images: Array.isArray(p.images) ? p.images : [],
    video: typeof p.video === "string" ? p.video : "",
    videoFile: typeof p.videoFile === "string" ? p.videoFile : "",
  }));

/** Live catalogue — database backed, realtime, shared by every visitor. */
export const productsStore = createLiveStore<Product[]>(
  [],
  async () => {
    const { data } = await supabase
      .from("products")
      .select("*")
      .order("sort_order", { ascending: true });
    return ((data ?? []) as Row[]).map(fromRow);
  },
  "products",
);

/** Unsaved admin edits to the catalogue. */
const draftStore = createMemoryStore<Product[] | null>(null);

const pushDraft = debounce((list: Product[] | null) => {
  const token = adminToken();
  if (!token) return;
  void saveDraft({ data: { token, kind: "products", data: list } });
}, 500);

export function hydrateProductDraft(draft: unknown) {
  draftStore.set(Array.isArray(draft) ? normalize(draft as Product[]) : null);
}

export const useProducts = () => productsStore.use();

export function useAdminProducts() {
  const draft = draftStore.use();
  const live = productsStore.use();
  return draft ?? live;
}

export const useHasProductDraft = () => draftStore.use() !== null;

const editable = () => draftStore.get() ?? productsStore.get();

function setDraft(list: Product[]) {
  draftStore.set(list);
  pushDraft(list);
}

export function upsertProduct(product: Product) {
  const list = editable();
  const i = list.findIndex((p) => p.id === product.id);
  setDraft(i === -1 ? [...list, product] : list.map((p) => (p.id === product.id ? product : p)));
}

export function removeProduct(id: string) {
  setDraft(editable().filter((p) => p.id !== id));
}

export function resetProducts() {
  setDraft(seedProducts);
}

export function importProducts(list: Product[], mode: "merge" | "replace") {
  if (mode === "replace") setDraft(normalize(list));
  else {
    const next = [...editable()];
    for (const p of normalize(list)) {
      const i = next.findIndex((x) => x.id === p.id);
      if (i === -1) next.push(p);
      else next[i] = p;
    }
    setDraft(next);
  }
}

/** Local cleanup after the server publishes the draft to the live table. */
export function publishProductDraft() {
  draftStore.set(null);
  void productsStore.refresh();
}

export function discardProductDraft() {
  draftStore.set(null);
}

export const productCsvHeader = [
  "id",
  "name",
  "price",
  "category",
  "image",
  "images",
  "video",
  "videoFile",
  "description",
  "inStock",
  "vatRate",
  "shippingFee",
  "discountPct",
];

export const sampleProductCsv = [
  productCsvHeader.join(","),
  'p-sample,"Indigo Wave Palazzo",130,Palazzo,https://example.com/front.jpg,"https://example.com/2.jpg|https://example.com/3.jpg",https://youtu.be/xxxx,https://example.com/clip.mp4,"Wide-leg indigo adire palazzo.",true,7.5,0,0',
].join("\n");

export const formatPrice = (n: number) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(n);
