export type ThemeTokens = {
  background: string;
  foreground: string;
  card: string;
  secondary: string;
  muted: string;
  mutedForeground: string;
  accent: string;
  accentForeground: string;
  border: string;
};

export type ThemePreset = { id: string; label: string; tokens: ThemeTokens };

export const themePresets: ThemePreset[] = [
  {
    id: "midnight-gold",
    label: "Midnight & Gold",
    tokens: {
      background: "#101526",
      foreground: "#f2f4f9",
      card: "#181e33",
      secondary: "#222941",
      muted: "#222941",
      mutedForeground: "#a9b1c6",
      accent: "#e0b24c",
      accentForeground: "#101526",
      border: "#2e3653",
    },
  },
  {
    id: "electric-blue",
    label: "Electric Blue",
    tokens: {
      background: "#080d1a",
      foreground: "#eef3ff",
      card: "#101a30",
      secondary: "#16233f",
      muted: "#16233f",
      mutedForeground: "#9db0d4",
      accent: "#4d8dff",
      accentForeground: "#04070f",
      border: "#22314f",
    },
  },
  {
    id: "ivory-ink",
    label: "Ivory & Ink",
    tokens: {
      background: "#f6f3ee",
      foreground: "#14171c",
      card: "#ffffff",
      secondary: "#ece7df",
      muted: "#ece7df",
      mutedForeground: "#5c6067",
      accent: "#b8863b",
      accentForeground: "#ffffff",
      border: "#ddd6cb",
    },
  },
  {
    id: "clay-emerald",
    label: "Clay & Emerald",
    tokens: {
      background: "#121a17",
      foreground: "#f0f5f2",
      card: "#182320",
      secondary: "#1f2d29",
      muted: "#1f2d29",
      mutedForeground: "#a2b5ad",
      accent: "#4fd39a",
      accentForeground: "#0a1310",
      border: "#283a34",
    },
  },
];

export const defaultTheme = themePresets[0]!.tokens;

export const cssVarMap: Record<keyof ThemeTokens, string[]> = {
  background: ["--background", "--popover"],
  foreground: ["--foreground", "--card-foreground", "--popover-foreground", "--secondary-foreground"],
  card: ["--card"],
  secondary: ["--secondary"],
  muted: ["--muted"],
  mutedForeground: ["--muted-foreground"],
  accent: ["--accent", "--primary", "--ring"],
  accentForeground: ["--accent-foreground", "--primary-foreground"],
  border: ["--border", "--input"],
};

export function themeToCss(tokens: ThemeTokens) {
  return (Object.keys(cssVarMap) as (keyof ThemeTokens)[])
    .flatMap((k) => cssVarMap[k].map((v) => `${v}:${tokens[k]}`))
    .join(";");
}

/* ---------- palette extraction from an uploaded screenshot ---------- */

type RGB = [number, number, number];

const hex = (c: RGB) =>
  "#" + c.map((n) => Math.max(0, Math.min(255, Math.round(n))).toString(16).padStart(2, "0")).join("");

const lum = (c: RGB) => (0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]) / 255;
const sat = (c: RGB) => {
  const mx = Math.max(c[0], c[1], c[2]);
  const mn = Math.min(c[0], c[1], c[2]);
  return mx === 0 ? 0 : (mx - mn) / mx;
};
const mix = (a: RGB, b: RGB, t: number): RGB => [
  a[0] + (b[0] - a[0]) * t,
  a[1] + (b[1] - a[1]) * t,
  a[2] + (b[2] - a[2]) * t,
];

export async function paletteFromImage(src: string): Promise<ThemeTokens> {
  const img = new Image();
  img.crossOrigin = "anonymous";
  img.src = src;
  await img.decode();

  const w = 120;
  const h = Math.max(1, Math.round((img.naturalHeight / img.naturalWidth) * w));
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d")!;
  ctx.drawImage(img, 0, 0, w, h);
  const { data } = ctx.getImageData(0, 0, w, h);

  const buckets = new Map<string, { c: RGB; n: number }>();
  for (let i = 0; i < data.length; i += 4) {
    if ((data[i + 3] ?? 0) < 200) continue;
    const c: RGB = [data[i] ?? 0, data[i + 1] ?? 0, data[i + 2] ?? 0];
    const key = c.map((v) => Math.round(v / 24)).join("-");
    const b = buckets.get(key) ?? { c: [0, 0, 0] as RGB, n: 0 };
    b.c = [b.c[0] + c[0], b.c[1] + c[1], b.c[2] + c[2]];
    b.n++;
    buckets.set(key, b);
  }
  const list = [...buckets.values()]
    .map((b) => ({ c: [b.c[0] / b.n, b.c[1] / b.n, b.c[2] / b.n] as RGB, n: b.n }))
    .sort((a, b) => b.n - a.n);
  const first = list[0];
  if (!first) return defaultTheme;

  const base = first.c;
  const accent: RGB =
    list
      .slice(0, 14)
      .filter((x) => sat(x.c) > 0.35 && lum(x.c) > 0.22 && lum(x.c) < 0.92)
      .sort((a, b) => sat(b.c) - sat(a.c))[0]?.c ??
    list.slice(1).sort((a, b) => sat(b.c) - sat(a.c))[0]?.c ?? [224, 178, 76];

  const dark = lum(base) < 0.5;
  const white: RGB = [255, 255, 255];
  const black: RGB = [10, 12, 16];
  const tint = dark ? white : black;

  return {
    background: hex(base),
    foreground: hex(mix(base, tint, 0.92)),
    card: hex(mix(base, tint, 0.07)),
    secondary: hex(mix(base, tint, 0.12)),
    muted: hex(mix(base, tint, 0.12)),
    mutedForeground: hex(mix(base, tint, 0.6)),
    accent: hex(accent),
    accentForeground: hex(lum(accent) > 0.6 ? black : white),
    border: hex(mix(base, tint, 0.2)),
  };
}
