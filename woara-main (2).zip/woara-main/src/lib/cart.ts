import { createStore } from "./store";

export type CartLine = {
  id: string;
  name: string;
  price: number;
  image: string;
  qty: number;
  vatRate?: number | undefined;
  shippingFee?: number | undefined;
  discountPct?: number | undefined;
};

export const cartStore = createStore<CartLine[]>("wo-ara-cart-v1", []);
export const useCart = () => cartStore.use();

export function addToCart(line: Omit<CartLine, "qty">, qty: number) {
  cartStore.set((c) => {
    const found = c.find((l) => l.id === line.id);
    if (found) return c.map((l) => (l.id === line.id ? { ...l, qty: l.qty + qty } : l));
    return [...c, { ...line, qty }];
  });
}

export function setQty(id: string, qty: number) {
  cartStore.set((c) =>
    qty <= 0 ? c.filter((l) => l.id !== id) : c.map((l) => (l.id === id ? { ...l, qty } : l)),
  );
}

export function removeLine(id: string) {
  cartStore.set((c) => c.filter((l) => l.id !== id));
}

export function clearCart() {
  cartStore.set([]);
}

export const cartTotal = (lines: CartLine[]) => lines.reduce((s, l) => s + l.price * l.qty, 0);
export const cartCount = (lines: CartLine[]) => lines.reduce((s, l) => s + l.qty, 0);

export const usd = (n: number) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(n);

export const ngn = (n: number) =>
  new Intl.NumberFormat("en-NG", { style: "currency", currency: "NGN", maximumFractionDigits: 0 }).format(n);

export type CheckoutConfig = {
  vatRate: number;
  shippingFee: number;
  freeShippingOver: number;
  discountPct: number;
  couponCode: string;
  couponPct: number;
};

export type Charges = {
  subtotal: number;
  discount: number;
  taxable: number;
  vat: number;
  shipping: number;
  total: number;
};

export function computeCharges(lines: CartLine[], cfg: CheckoutConfig, code = ""): Charges {
  const subtotal = cartTotal(lines);
  const coupon = code.trim().toUpperCase() === cfg.couponCode.trim().toUpperCase() && code.trim() !== "";

  let discount = 0;
  for (const l of lines) {
    const pct = (l.discountPct ?? cfg.discountPct) + (coupon ? cfg.couponPct : 0);
    discount += l.price * l.qty * (pct / 100);
  }
  discount = Math.min(discount, subtotal);

  let vat = 0;
  for (const l of lines) {
    const gross = l.price * l.qty;
    const pct = (l.discountPct ?? cfg.discountPct) + (coupon ? cfg.couponPct : 0);
    vat += gross * (1 - pct / 100) * ((l.vatRate ?? cfg.vatRate) / 100);
  }

  const extras = lines.reduce((s, l) => s + (l.shippingFee ?? 0), 0);
  const base = subtotal - discount >= cfg.freeShippingOver && cfg.freeShippingOver > 0 ? 0 : cfg.shippingFee;
  const shipping = lines.length ? base + extras : 0;

  const taxable = subtotal - discount;
  return {
    subtotal,
    discount,
    taxable,
    vat,
    shipping,
    total: Math.max(0, taxable + vat + shipping),
  };
}
