import { useSyncExternalStore } from "react";

export function createStore<T>(key: string, seed: T) {
  let state: T = seed;
  let hydrated = false;
  const listeners = new Set<() => void>();

  function hydrate() {
    if (typeof window === "undefined") return;
    try {
      const raw = localStorage.getItem(key);
      if (raw) {
        const parsed = JSON.parse(raw);
        state =
          parsed && typeof parsed === "object" && !Array.isArray(parsed) && !Array.isArray(seed)
            ? { ...(seed as object), ...(parsed as object) } as T
            : (parsed as T);
      }
    } catch {
      /* ignore */
    }
  }

  function persist() {
    if (typeof window === "undefined") return;
    try {
      localStorage.setItem(key, JSON.stringify(state));
    } catch {
      /* ignore */
    }
  }

  function emit() {
    persist();
    listeners.forEach((l) => l());
  }

  function subscribe(cb: () => void) {
    if (!hydrated) {
      hydrated = true;
      hydrate();
    }
    listeners.add(cb);
    const onStorage = (e: StorageEvent) => {
      if (e.key === key) {
        hydrate();
        listeners.forEach((l) => l());
      }
    };
    window.addEventListener("storage", onStorage);
    return () => {
      listeners.delete(cb);
      window.removeEventListener("storage", onStorage);
    };
  }

  return {
    get: () => state,
    set(next: T | ((prev: T) => T)) {
      state = typeof next === "function" ? (next as (p: T) => T)(state) : next;
      emit();
    },
    reset() {
      state = seed;
      emit();
    },
    use() {
      return useSyncExternalStore(
        subscribe,
        () => state,
        () => seed,
      );
    },
  };
}
