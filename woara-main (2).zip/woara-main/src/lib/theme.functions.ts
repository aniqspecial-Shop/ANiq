import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const schema = z.object({ url: z.string().url() });

/** Fetches a website and extracts its most-used colors so the studio can adopt its theme. */
export const fetchSiteColors = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => schema.parse(data))
  .handler(async ({ data }) => {
    const res = await fetch(data.url, {
      headers: { "user-agent": "Mozilla/5.0 (compatible; WoAraThemeBot/1.0)" },
    });
    if (!res.ok) throw new Error(`Could not reach that site (${res.status}).`);
    let text = await res.text();

    const cssLinks = [...text.matchAll(/<link[^>]+href=["']([^"']+\.css[^"']*)["']/gi)]
      .map((m) => m[1] ?? "")
      .filter(Boolean)
      .slice(0, 3);
    for (const href of cssLinks) {
      try {
        const abs = new URL(href, data.url).toString();
        const r = await fetch(abs);
        if (r.ok) text += await r.text();
      } catch {
        /* ignore */
      }
    }

    const counts = new Map<string, number>();
    const add = (c: string) => counts.set(c, (counts.get(c) ?? 0) + 1);

    for (const m of text.matchAll(/#([0-9a-f]{6}|[0-9a-f]{3})\b/gi)) {
      let h = (m[1] ?? "").toLowerCase();
      if (h.length === 3) h = h.split("").map((c) => c + c).join("");
      add("#" + h);
    }
    for (const m of text.matchAll(/rgba?\(\s*(\d+)[\s,]+(\d+)[\s,]+(\d+)/gi)) {
      const h =
        "#" +
        [m[1] ?? "0", m[2] ?? "0", m[3] ?? "0"]
          .map((n) => Math.min(255, Number(n)).toString(16).padStart(2, "0"))
          .join("");
      add(h);
    }

    const colors = [...counts.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 24)
      .map(([hex, n]) => ({ hex, n }));

    if (!colors.length) throw new Error("No colors found on that page.");
    return { colors };
  });
