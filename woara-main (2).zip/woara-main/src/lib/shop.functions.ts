import { createServerFn } from "@tanstack/react-start";

/**
 * Every admin write goes through here. The browser never holds database
 * credentials — it holds a short-lived admin session token that the server
 * checks against the `admin_sessions` table before touching anything.
 */

// Loose JSON shape: these payloads are validated at the boundaries below.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
type Json = any;

const SESSION_HOURS = 12;

async function db() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

async function authed(token: string) {
  const client = await db();
  if (!token) throw new Error("Admin session required.");
  const { data } = await client
    .from("admin_sessions")
    .select("token, expires_at")
    .eq("token", token)
    .maybeSingle();
  if (!data || new Date(data.expires_at).getTime() < Date.now()) {
    throw new Error("Admin session expired — sign in again.");
  }
  return client;
}

async function currentPassword(client: Awaited<ReturnType<typeof db>>) {
  const { data } = await client.from("admin_config").select("password").eq("id", true).maybeSingle();
  return data?.password ?? "";
}

export const adminLogin = createServerFn({ method: "POST" })
  .inputValidator((input: { password: string }) => ({ password: String(input?.password ?? "") }))
  .handler(async ({ data }) => {
    const client = await db();
    const expected = await currentPassword(client);
    if (!expected || data.password !== expected) return { ok: false as const, token: "" };

    await client.from("admin_sessions").delete().lt("expires_at", new Date().toISOString());
    const token = `${crypto.randomUUID()}${crypto.randomUUID()}`.replace(/-/g, "");
    const expiresAt = new Date(Date.now() + SESSION_HOURS * 3600_000).toISOString();
    const { error } = await client.from("admin_sessions").insert({ token, expires_at: expiresAt });
    if (error) throw new Error(error.message);
    return { ok: true as const, token };
  });

export const adminLogout = createServerFn({ method: "POST" })
  .inputValidator((input: { token: string }) => ({ token: String(input?.token ?? "") }))
  .handler(async ({ data }) => {
    const client = await db();
    await client.from("admin_sessions").delete().eq("token", data.token);
    return { ok: true };
  });

/** Everything the admin screens need that shoppers must never see. */
export const loadAdminState = createServerFn({ method: "POST" })
  .inputValidator((input: { token: string }) => ({ token: String(input?.token ?? "") }))
  .handler(async ({ data }) => {
    const empty = {
      ok: false as const,
      contentDraft: null as Json | null,
      productDraft: null as Json[] | null,
      orders: [] as Json[],
      events: [] as Json[],
      adminPassword: "",
    };

    // An expired or unknown session is a normal signed-out state, not a crash.
    const client = await db();
    const { data: session } = await client
      .from("admin_sessions")
      .select("expires_at")
      .eq("token", data.token)
      .maybeSingle();
    if (!data.token || !session || new Date(session.expires_at).getTime() < Date.now()) return empty;

    const [drafts, orders, events, password] = await Promise.all([
      client.from("drafts").select("id, data"),
      client.from("orders").select("*").order("created_at", { ascending: false }).limit(500),
      client.from("analytics_events").select("type, label, created_at").order("created_at", { ascending: false }).limit(5000),
      currentPassword(client),
    ]);

    const draftRow = (id: string) => drafts.data?.find((d) => d.id === id)?.data ?? null;

    return {
      ok: true as const,
      contentDraft: draftRow("content") as Json | null,
      productDraft: draftRow("products") as Json[] | null,
      orders: orders.data ?? [],
      events: events.data ?? [],
      adminPassword: password,
    };
  });


export const saveDraft = createServerFn({ method: "POST" })
  .inputValidator((input: { token: string; kind: "content" | "products"; data: unknown }) => ({
    token: String(input?.token ?? ""),
    kind: input?.kind === "products" ? ("products" as const) : ("content" as const),
    data: input?.data ?? null,
  }))
  .handler(async ({ data }) => {
    const client = await authed(data.token);
    if (data.data === null) {
      await client.from("drafts").delete().eq("id", data.kind);
      return { ok: true };
    }
    const { error } = await client
      .from("drafts")
      .upsert({ id: data.kind, data: data.data as Json, updated_at: new Date().toISOString() });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const discardDrafts = createServerFn({ method: "POST" })
  .inputValidator((input: { token: string }) => ({ token: String(input?.token ?? "") }))
  .handler(async ({ data }) => {
    const client = await authed(data.token);
    await client.from("drafts").delete().in("id", ["content", "products"]);
    return { ok: true };
  });

type ProductRow = {
  id: string;
  name: string;
  price: number;
  category: string;
  image: string;
  images: string[];
  video: string;
  videoFile?: string;
  description: string;
  inStock: boolean;
  vatRate?: number | null;
  shippingFee?: number | null;
  discountPct?: number | null;
};

/** Publishes pending admin edits to the live tables shoppers read. */
export const publishDrafts = createServerFn({ method: "POST" })
  .inputValidator((input: { token: string; password: string }) => ({
    token: String(input?.token ?? ""),
    password: String(input?.password ?? ""),
  }))
  .handler(async ({ data }) => {
    const client = await authed(data.token);
    const expected = await currentPassword(client);
    if (data.password !== expected) return { ok: false as const, error: "Wrong admin password." };

    const { data: drafts } = await client.from("drafts").select("id, data");
    const contentDraft = drafts?.find((d) => d.id === "content")?.data as Json | undefined;
    const productDraft = drafts?.find((d) => d.id === "products")?.data as ProductRow[] | undefined;

    if (contentDraft) {
      const clone = structuredClone(contentDraft) as Json;
      // The password lives in `admin_config`, never in publicly readable content.
      const settings = clone["settings"] as Json | undefined;
      if (settings) delete settings["adminPassword"];
      const { error } = await client
        .from("site_content")
        .upsert({ id: "live", data: clone, updated_at: new Date().toISOString() });
      if (error) throw new Error(error.message);
    }

    if (Array.isArray(productDraft)) {
      const rows = productDraft.map((p, i) => ({
        id: p.id,
        name: p.name ?? "",
        price: Number(p.price) || 0,
        category: p.category ?? "",
        image: p.image ?? "",
        images: Array.isArray(p.images) ? p.images : [],
        video: p.video ?? "",
        video_file: p.videoFile ?? "",
        description: p.description ?? "",
        in_stock: p.inStock !== false,
        vat_rate: p.vatRate ?? null,
        shipping_fee: p.shippingFee ?? null,
        discount_pct: p.discountPct ?? null,
        sort_order: i,
        updated_at: new Date().toISOString(),
      }));
      if (rows.length) {
        const { error } = await client.from("products").upsert(rows);
        if (error) throw new Error(error.message);
        await client.from("products").delete().not("id", "in", `(${rows.map((r) => `"${r.id}"`).join(",")})`);
      } else {
        await client.from("products").delete().neq("id", "");
      }
    }

    await client.from("drafts").delete().in("id", ["content", "products"]);
    return { ok: true as const };
  });

/* ---------------- orders ---------------- */

export const placeOrder = createServerFn({ method: "POST" })
  .inputValidator((input: Json) => input ?? {})
  .handler(async ({ data }) => {
    const client = await db();
    const items = Array.isArray(data["items"]) ? (data["items"] as unknown[]).slice(0, 50) : [];
    const num = (k: string) => Number(data[k]) || 0;
    const str = (k: string, max = 200) => String(data[k] ?? "").slice(0, max);
    if (!items.length) throw new Error("An order needs at least one item.");

    const row = {
      id: str("id", 60) || crypto.randomUUID(),
      ref: str("ref", 40),
      name: str("name", 120),
      phone: str("phone", 40),
      note: str("note", 1000),
      items: items as Json,
      subtotal: num("subtotal"),
      discount: num("discount"),
      vat: num("vat"),
      shipping: num("shipping"),
      total: num("total"),
      ngn_rate: num("ngnRate"),
      status: "pending",
      receipt: "",
    };
    const { error } = await client.from("orders").insert(row);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const saveOrder = createServerFn({ method: "POST" })
  .inputValidator((input: { token: string; id: string; patch: Json }) => ({
    token: String(input?.token ?? ""),
    id: String(input?.id ?? ""),
    patch: input?.patch ?? {},
  }))
  .handler(async ({ data }) => {
    const client = await authed(data.token);
    const p = data.patch;
    const row: Json = {};
    if (typeof p["status"] === "string") row["status"] = p["status"];
    if (typeof p["receipt"] === "string") row["receipt"] = p["receipt"];
    if (typeof p["note"] === "string") row["note"] = p["note"];
    if (p["approvedAt"]) row["approved_at"] = new Date(Number(p["approvedAt"])).toISOString();
    const { error } = await client.from("orders").update(row).eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteOrder = createServerFn({ method: "POST" })
  .inputValidator((input: { token: string; id: string }) => ({
    token: String(input?.token ?? ""),
    id: String(input?.id ?? ""),
  }))
  .handler(async ({ data }) => {
    const client = await authed(data.token);
    await client.from("orders").delete().eq("id", data.id);
    return { ok: true };
  });

export const clearAnalytics = createServerFn({ method: "POST" })
  .inputValidator((input: { token: string }) => ({ token: String(input?.token ?? "") }))
  .handler(async ({ data }) => {
    const client = await authed(data.token);
    await client.from("analytics_events").delete().neq("type", "");
    return { ok: true };
  });

/** Changes the admin password immediately (it is never stored in site content). */
export const setAdminPassword = createServerFn({ method: "POST" })
  .inputValidator((input: { token: string; password: string }) => ({
    token: String(input?.token ?? ""),
    password: String(input?.password ?? ""),
  }))
  .handler(async ({ data }) => {
    const client = await authed(data.token);
    if (data.password.length < 6) return { ok: false as const, error: "Use at least 6 characters." };
    const { error } = await client
      .from("admin_config")
      .update({ password: data.password, updated_at: new Date().toISOString() })
      .eq("id", true);
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });
