import { supabase } from "@/integrations/supabase/client";
import { createLiveStore, createMemoryStore, debounce } from "./live";
import { adminToken } from "./admin-session";
import { saveDraft } from "./shop.functions";
import { defaultTheme, type ThemeTokens } from "./theme";
import p1 from "@/assets/p1.png.asset.json";
import p2 from "@/assets/p2.png.asset.json";
import p3 from "@/assets/p3.png.asset.json";
import p4 from "@/assets/p4.png.asset.json";

export type HeroSlide = {
  id: string;
  image: string;
  eyebrow: string;
  title: string;
  subtitle: string;
  ctaLabel: string;
};

export type GalleryItem = { id: string; image: string; caption: string; description: string };

export type Ad = {
  id: string;
  active: boolean;
  image: string;
  title: string;
  text: string;
  ctaLabel: string;
  ctaUrl: string;
};

export type SiteContent = {
  hero: {
    slides: HeroSlide[];
    intervalMs: number;
  };
  collection: { title: string; blurb: string };
  about: {
    eyebrow: string;
    title: string;
    body: string[];
    image: string;
  };
  gallery: {
    title: string;
    blurb: string;
    items: GalleryItem[];
    hero: { video: string; poster: string; title: string; subtitle: string };
  };
  contact: {
    title: string;
    blurb: string;
    email: string;
    phone: string;
    address: string;
    instagram: string;
  };
  ads: Ad[];
  logo: { mode: "text" | "image"; image: string; primary: string; secondary: string };
  theme: { preset: string; tokens: ThemeTokens };
  checkout: {
    vatRate: number;
    shippingFee: number;
    freeShippingOver: number;
    discountPct: number;
    couponCode: string;
    couponPct: number;
  };
  approvals: { requireReceipt: boolean };
  settings: {
    whatsapp: string;
    checkoutMessage: string;
    ngnRate: number;
    tagline: string;
    adminPassword: string;
  };
};

export const defaultContent: SiteContent = {
  hero: {
    intervalMs: 5500,
    slides: [
      {
        id: "h1",
        image: p3.url,
        eyebrow: "Drop 01 — Lagos",
        title: "Cloth that carries a name.",
        subtitle: "Hand-printed adire and ankara palazzo, cut in runs of four.",
        ctaLabel: "Shop the drop",
      },
      {
        id: "h2",
        image: p2.url,
        eyebrow: "Limited run",
        title: "Wide legs. Old dye. New cut.",
        subtitle: "No two panels fall the same way — each pair is one of one.",
        ctaLabel: "See the collection",
      },
      {
        id: "h3",
        image: p4.url,
        eyebrow: "Made in Lagos",
        title: "Wear wonder, every day.",
        subtitle: "Soft waists, deep pockets, cloth that moves with you.",
        ctaLabel: "Browse pieces",
      },
    ],
  },
  collection: {
    title: "The Collection",
    blurb: "Four pieces in this run — when they are gone, they are gone.",
  },
  about: {
    eyebrow: "About Us",
    title: "Wọ Àrá means to wear wonder.",
    image: p1.url,
    body: [
      "We work with dyers and printers across Abeokuta and Lagos, buying cloth in short lengths and cutting what the cloth allows. That means runs of four, six, sometimes one.",
      "Every palazzo is drafted for movement — a full leg, a soft waist, pockets deep enough to be useful. Nothing is lined, nothing is stiff, nothing is made twice the same.",
    ],
  },
  gallery: {
    title: "The Gallery",
    blurb: "Pieces in the studio, on the street, and on the people who wear them.",
    items: [
      {
        id: "g1",
        image: p1.url,
        caption: "Charcoal brushstroke, studio light",
        description: "Hand-brushed adire, photographed the morning it came off the line.",
      },
      { id: "g2", image: p2.url, caption: "Amethyst marble", description: "Tie-dye marbling in purple and gold — one of four." },
      { id: "g3", image: p3.url, caption: "Patchwork heritage", description: "Vintage adire panels stitched into a one-of-one." },
      { id: "g4", image: p4.url, caption: "Teal feather ankara", description: "Feather-print ankara cut full through the leg." },
    ],
    hero: {
      video: "",
      poster: p3.url,
      title: "Welcome to Wọ Àrá",
      subtitle: "Cloth in motion — the studio, the street, the people who wear it.",
    },
  },
  contact: {
    title: "Contact Us",
    blurb: "Questions on sizing, shipping or a custom cut? Reach us any way you like.",
    email: "hello@woara.com",
    phone: "+1 (437) 962-2003",
    address: "Studio 4, Lagos, Nigeria",
    instagram: "https://instagram.com",
  },
  ads: [
    {
      id: "a1",
      active: true,
      image: p2.url,
      title: "Free delivery within Lagos",
      text: "On every order from Drop 01 — worldwide shipping quoted at checkout.",
      ctaLabel: "Shop now",
      ctaUrl: "/",
    },
  ],
  logo: { mode: "text", image: "", primary: "WỌ", secondary: "ÀRÁ" },
  theme: { preset: "midnight-gold", tokens: defaultTheme },
  checkout: {
    vatRate: 7.5,
    shippingFee: 25,
    freeShippingOver: 400,
    discountPct: 0,
    couponCode: "WOARA10",
    couponPct: 10,
  },
  approvals: { requireReceipt: true },
  settings: {
    whatsapp: "+14379622003",
    checkoutMessage:
      "Hello Wọ Àrá! I'd like to place an order for the following pieces:",
    ngnRate: 1550,
    tagline: "Hand-printed adire & ankara palazzo, cut in small runs in Lagos.",
    adminPassword: "Woara@2026",
  },
};

type Dict = Record<string, unknown>;
const isPlain = (v: unknown): v is Dict => !!v && typeof v === "object" && !Array.isArray(v);

/** Fills in any keys added after a copy was stored. */
function withDefaults<T>(base: T, saved: unknown): T {
  if (!isPlain(base) || !isPlain(saved)) return (saved === undefined ? base : (saved as T));
  const out: Dict = { ...base };
  for (const [k, v] of Object.entries(saved)) out[k] = withDefaults((base as Dict)[k], v);
  return out as T;
}

/** Live site content — read from the database, kept in sync in real time. */
export const contentStore = createLiveStore<SiteContent>(
  defaultContent,
  async () => {
    const { data } = await supabase.from("site_content").select("data").eq("id", "live").maybeSingle();
    return withDefaults(defaultContent, data?.data ?? {});
  },
  "site_content",
);

/** What shoppers see. */
export const useContent = () => contentStore.use();

/** Unsaved admin edits. `null` means "nothing pending". */
export const draftStore = createMemoryStore<SiteContent | null>(null);

const pushDraft = debounce((data: SiteContent | null) => {
  const token = adminToken();
  if (!token) return;
  void saveDraft({ data: { token, kind: "content", data } });
}, 500);

/** Called once the admin signs in, with whatever draft the server is holding. */
export function hydrateContentDraft(draft: unknown) {
  draftStore.set(draft ? withDefaults(defaultContent, draft) : null);
}

/** What the admin screens edit: pending changes if any, otherwise the live copy. */
export const useAdminContent = () => {
  const draft = draftStore.use();
  const live = contentStore.use();
  return withDefaults(defaultContent, draft ?? live);
};

export const useHasContentDraft = () => draftStore.use() !== null;

export function updateContent(patch: (c: SiteContent) => SiteContent) {
  const base = draftStore.get() ?? contentStore.get();
  const next = patch(structuredClone(base));
  draftStore.set(next);
  pushDraft(next);
}

/** Local cleanup after the server has published the draft. */
export function publishContentDraft() {
  draftStore.set(null);
  void contentStore.refresh();
}

export function discardContentDraft() {
  draftStore.set(null);
}

export const uid = () => Math.random().toString(36).slice(2, 9);


