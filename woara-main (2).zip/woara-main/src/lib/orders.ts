import { createMemoryStore } from "./live";
import { adminToken } from "./admin-session";
import { deleteOrder, placeOrder, saveOrder } from "./shop.functions";
import { uid } from "./content";

export type OrderItem = {
  id: string;
  name: string;
  price: number;
  qty: number;
  image: string;
};

export type OrderStatus = "pending" | "approved" | "cancelled";

export type Order = {
  id: string;
  ref: string;
  createdAt: number;
  approvedAt?: number;
  name: string;
  phone: string;
  note: string;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  vat: number;
  shipping: number;
  total: number;
  ngnRate: number;
  status: OrderStatus;
  receipt: string;
};

type Row = Record<string, unknown>;

export const ordersStore = createMemoryStore<Order[]>([]);
export const useOrders = () => ordersStore.use();

const n = (v: unknown) => Number(v ?? 0) || 0;

export function hydrateOrders(rows: unknown) {
  if (!Array.isArray(rows)) return;
  ordersStore.set(
    (rows as Row[]).map((r) => ({
      id: String(r["id"]),
      ref: String(r["ref"] ?? ""),
      createdAt: new Date(String(r["created_at"])).getTime(),
      ...(r["approved_at"] ? { approvedAt: new Date(String(r["approved_at"])).getTime() } : {}),
      name: String(r["name"] ?? ""),
      phone: String(r["phone"] ?? ""),
      note: String(r["note"] ?? ""),
      items: Array.isArray(r["items"]) ? (r["items"] as OrderItem[]) : [],
      subtotal: n(r["subtotal"]),
      discount: n(r["discount"]),
      vat: n(r["vat"]),
      shipping: n(r["shipping"]),
      total: n(r["total"]),
      ngnRate: n(r["ngn_rate"]),
      status: (String(r["status"] ?? "pending") as OrderStatus) ?? "pending",
      receipt: String(r["receipt"] ?? ""),
    })),
  );
}

/** Placed by shoppers at checkout — written straight to the database. */
export function createOrder(o: Omit<Order, "id" | "ref" | "createdAt" | "status" | "receipt">) {
  const order: Order = {
    ...o,
    id: typeof crypto !== "undefined" && crypto.randomUUID ? crypto.randomUUID() : uid(),
    ref: `WA-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
    createdAt: Date.now(),
    status: "pending",
    receipt: "",
  };
  ordersStore.set((list) => [order, ...list]);
  void placeOrder({ data: { ...order } as unknown as Record<string, unknown> });
  return order;
}

export function updateOrder(id: string, patch: Partial<Order>) {
  ordersStore.set((list) => list.map((o) => (o.id === id ? { ...o, ...patch } : o)));
  const token = adminToken();
  if (!token) return;
  void saveOrder({ data: { token, id, patch: patch as Record<string, unknown> } });
}

export function approveOrder(id: string) {
  updateOrder(id, { status: "approved", approvedAt: Date.now() });
}

export function removeOrder(id: string) {
  ordersStore.set((list) => list.filter((o) => o.id !== id));
  const token = adminToken();
  if (!token) return;
  void deleteOrder({ data: { token, id } });
}

export const orderDate = (t: number) => new Date(t).toLocaleString();
