import { createStore } from "./store";

/** Short-lived admin session token issued by the server after a password login. */
export const adminTokenStore = createStore<string>("wo-ara-admin-token-v1", "");
export const useAdminToken = () => adminTokenStore.use();
export const adminToken = () => adminTokenStore.get();
