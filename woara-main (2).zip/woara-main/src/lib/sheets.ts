import { createStore } from "./store";

export type SheetsState = {
  spreadsheetId: string;
  url: string;
  lastSyncedAt: number;
};

export const sheetsStore = createStore<SheetsState>("wo-ara-sheets-v1", {
  spreadsheetId: "",
  url: "",
  lastSyncedAt: 0,
});

export const useSheets = () => sheetsStore.use();
