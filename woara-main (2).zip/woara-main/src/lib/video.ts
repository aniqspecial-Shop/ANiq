export type ResolvedVideo = {
  /** "iframe" = platform player, "file" = direct video file, "none" = nothing usable. */
  kind: "iframe" | "file" | "none";
  src: string;
  /** Vertical players (reels, shorts, tiktok) look best in a 9:16 frame. */
  portrait: boolean;
  provider: string;
  /** True when the video starts playing on its own, with no post card or play button. */
  instant: boolean;
};

const clean = (raw: string) => raw.trim().replace(/^@/, "");

function id(url: string, re: RegExp) {
  const m = url.match(re);
  return m?.[1] ?? "";
}

const none: ResolvedVideo = { kind: "none", src: "", portrait: false, provider: "", instant: false };

/**
 * Turns almost any pasted video link into something we can actually render, and
 * prefers a player that starts on its own instead of a social post card.
 */
export function resolveVideo(raw: string, opts: { autoplay?: boolean; loop?: boolean; muted?: boolean } = {}): ResolvedVideo {
  const url = clean(raw ?? "");
  if (!url) return none;

  const autoplay = opts.autoplay !== false;
  const loop = opts.loop ?? false;
  // Browsers only allow unattended playback when the track starts muted.
  const muted = opts.muted ?? autoplay;
  const flag = (on: boolean) => (on ? "1" : "0");

  // Already an embed/player URL — trust it.
  if (/\/(embed|player|plugins\/video\.php|embed\/v2)\//.test(url) && /^https?:\/\//.test(url)) {
    const social = /tiktok|instagram|twitter|x\.com|facebook/.test(url);
    return { kind: "iframe", src: url, portrait: /tiktok|reel|shorts/.test(url), provider: "embed", instant: !social };
  }

  // Direct file or stream
  if (/\.(mp4|webm|ogg|ogv|mov|m4v)(\?|#|$)/i.test(url) || url.startsWith("data:video") || url.startsWith("blob:")) {
    return { kind: "file", src: url, portrait: false, provider: "file", instant: true };
  }

  const yt = id(url, /(?:youtu\.be\/|youtube(?:-nocookie)?\.com\/(?:watch\?(?:.*&)?v=|embed\/|shorts\/|live\/|v\/))([\w-]{6,})/);
  if (yt) {
    const q = `autoplay=${flag(autoplay)}&mute=${flag(muted || loop)}&rel=0&modestbranding=1&controls=1&playsinline=1&iv_load_policy=3${loop ? `&loop=1&playlist=${yt}` : ""}`;
    return {
      kind: "iframe",
      src: `https://www.youtube-nocookie.com/embed/${yt}?${q}`,
      portrait: /shorts\//.test(url),
      provider: "youtube",
      instant: true,
    };
  }

  const vm = id(url, /vimeo\.com\/(?:video\/)?(\d+)/);
  if (vm) {
    const q = `autoplay=${flag(autoplay)}&muted=${flag(muted || loop)}&title=0&byline=0&portrait=0&dnt=1${loop ? "&loop=1" : ""}`;
    return { kind: "iframe", src: `https://player.vimeo.com/video/${vm}?${q}`, portrait: false, provider: "vimeo", instant: true };
  }

  const ig = id(url, /instagram\.com\/(?:[\w.]+\/)?(?:reels?|p|tv)\/([\w-]+)/);
  if (ig) {
    // Plain embed (no captions block); Instagram still requires a tap to start.
    return { kind: "iframe", src: `https://www.instagram.com/p/${ig}/embed/`, portrait: true, provider: "instagram", instant: false };
  }

  const tt = id(url, /tiktok\.com\/(?:.*\/video\/|v\/|embed\/v2\/)(\d+)/);
  if (tt) return { kind: "iframe", src: `https://www.tiktok.com/embed/v2/${tt}`, portrait: true, provider: "tiktok", instant: false };

  const tw = id(url, /(?:twitter|x)\.com\/[^/]+\/status(?:es)?\/(\d+)/);
  if (tw) {
    return {
      kind: "iframe",
      src: `https://platform.twitter.com/embed/Tweet.html?id=${tw}&theme=dark&hideCard=true&hideThread=true`,
      portrait: true,
      provider: "x",
      instant: false,
    };
  }

  if (/facebook\.com|fb\.watch/.test(url)) {
    return {
      kind: "iframe",
      src: `https://www.facebook.com/plugins/video.php?href=${encodeURIComponent(url)}&autoplay=${flag(autoplay)}&mute=${flag(muted)}&show_text=false`,
      portrait: /reel/.test(url),
      provider: "facebook",
      instant: false,
    };
  }

  const dm = id(url, /(?:dailymotion\.com\/video\/|dai\.ly\/)([\w]+)/);
  if (dm) {
    return {
      kind: "iframe",
      src: `https://www.dailymotion.com/embed/video/${dm}?autoplay=${flag(autoplay)}&mute=${flag(muted)}&ui-logo=0&ui-start-screen-info=0`,
      portrait: false,
      provider: "dailymotion",
      instant: true,
    };
  }

  const st = id(url, /streamable\.com\/(?:e\/)?([\w]+)/);
  if (st) {
    return {
      kind: "iframe",
      src: `https://streamable.com/e/${st}?autoplay=${flag(autoplay)}&muted=${flag(muted)}`,
      portrait: false,
      provider: "streamable",
      instant: true,
    };
  }

  const lo = id(url, /loom\.com\/(?:share|embed)\/([\w]+)/);
  if (lo) {
    return {
      kind: "iframe",
      src: `https://www.loom.com/embed/${lo}?autoplay=${flag(autoplay)}&muted=${flag(muted)}&hideEmbedTopBar=true&hide_owner=true&hide_title=true`,
      portrait: false,
      provider: "loom",
      instant: true,
    };
  }

  const wi = id(url, /(?:wistia\.com|wi\.st)\/(?:medias|embed\/medias)\/([\w]+)/);
  if (wi) {
    return {
      kind: "iframe",
      src: `https://fast.wistia.net/embed/iframe/${wi}?autoPlay=${flag(autoplay)}&muted=${flag(muted)}&playbar=true`,
      portrait: false,
      provider: "wistia",
      instant: true,
    };
  }

  const tv = id(url, /twitch\.tv\/videos\/(\d+)/);
  if (tv) {
    const host = typeof window === "undefined" ? "localhost" : window.location.hostname;
    return {
      kind: "iframe",
      src: `https://player.twitch.tv/?video=${tv}&parent=${host}&autoplay=${autoplay}&muted=${muted}`,
      portrait: false,
      provider: "twitch",
      instant: true,
    };
  }

  const gd = id(url, /drive\.google\.com\/file\/d\/([\w-]+)/);
  if (gd) return { kind: "iframe", src: `https://drive.google.com/file/d/${gd}/preview`, portrait: false, provider: "drive", instant: true };

  // Unknown http link — try it as a file, the player will show controls or fail gracefully.
  if (/^https?:\/\//.test(url)) return { kind: "file", src: url, portrait: false, provider: "link", instant: true };

  return none;
}

/** Picks the source that plays instantly when the shop has both a file and a social link. */
export function bestVideo(file: string | undefined, link: string | undefined, opts?: Parameters<typeof resolveVideo>[1]) {
  const direct = resolveVideo(file ?? "", opts);
  if (direct.kind !== "none") return direct;
  return resolveVideo(link ?? "", opts);
}
