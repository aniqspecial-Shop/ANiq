import { useSyncExternalStore } from "react";
import { supabase } from "@/integrations/supabase/client";

/**
 * A read-through store for a public table: loads once, then keeps itself in
 * sync with database changes so every open tab updates without a refresh.
 */
export function createLiveStore<T>(seed: T, load: () => Promise<T>, table: string) {
  let state: T = seed;
  let started = false;
  const listeners = new Set<() => void>();
  const emit = () => listeners.forEach((l) => l());

  async function refresh() {
    try {
      state = await load();
      emit();
    } catch {
      /* keep the last good copy */
    }
  }

  function start() {
    if (started || typeof window === "undefined") return;
    started = true;
    void refresh();
    // A unique channel name per subscription: reusing a name returns a channel
    // that is already subscribed, which Supabase rejects.
    const channel = supabase.channel(`live:${table}:${Math.random().toString(36).slice(2)}`);
    channel
      .on("postgres_changes", { event: "*", schema: "public", table }, () => {
        void refresh();
      })
      .subscribe();
  }


  return {
    get: () => state,
    set(next: T) {
      state = next;
      emit();
    },
    refresh,
    use() {
      return useSyncExternalStore(
        (cb) => {
          start();
          listeners.add(cb);
          return () => listeners.delete(cb);
        },
        () => state,
        () => seed,
      );
    },
  };
}

/** Tiny in-memory reactive value (admin drafts, orders, analytics). */
export function createMemoryStore<T>(seed: T) {
  let state = seed;
  const listeners = new Set<() => void>();
  return {
    get: () => state,
    set(next: T | ((prev: T) => T)) {
      state = typeof next === "function" ? (next as (p: T) => T)(state) : next;
      listeners.forEach((l) => l());
    },
    use() {
      return useSyncExternalStore(
        (cb) => {
          listeners.add(cb);
          return () => listeners.delete(cb);
        },
        () => state,
        () => seed,
      );
    },
  };
}

/** Debounced persistence so typing in the admin doesn't hammer the server. */
export function debounce<A extends unknown[]>(fn: (...args: A) => void, ms: number) {
  let t: ReturnType<typeof setTimeout> | undefined;
  return (...args: A) => {
    if (t) clearTimeout(t);
    t = setTimeout(() => fn(...args), ms);
  };
}
