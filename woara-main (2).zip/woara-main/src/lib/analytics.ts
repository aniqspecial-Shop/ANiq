import { useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { createMemoryStore } from "./live";

export type Analytics = {
  pageViews: Record<string, number>;
  productClicks: Record<string, number>;
  adClicks: Record<string, number>;
  addToCart: number;
  checkouts: number;
  events: { t: number; type: string; label: string }[];
};

const seed: Analytics = {
  pageViews: {},
  productClicks: {},
  adClicks: {},
  addToCart: 0,
  checkouts: 0,
  events: [],
};

export const analyticsStore = createMemoryStore<Analytics>(seed);
export const useAnalytics = () => analyticsStore.use();

type Event = { type: string; label: string; created_at: string };

/** Turns raw event rows from the database into the dashboard shape. */
export function hydrateAnalytics(rows: unknown) {
  if (!Array.isArray(rows)) return;
  const a: Analytics = { pageViews: {}, productClicks: {}, adClicks: {}, addToCart: 0, checkouts: 0, events: [] };
  for (const e of rows as Event[]) {
    if (e.type === "view") a.pageViews[e.label] = (a.pageViews[e.label] ?? 0) + 1;
    if (e.type === "product") a.productClicks[e.label] = (a.productClicks[e.label] ?? 0) + 1;
    if (e.type === "ad") a.adClicks[e.label] = (a.adClicks[e.label] ?? 0) + 1;
    if (e.type === "cart") a.addToCart += 1;
    if (e.type === "checkout") a.checkouts += 1;
  }
  a.events = (rows as Event[])
    .slice(0, 100)
    .map((e) => ({ t: new Date(e.created_at).getTime(), type: e.type, label: e.label }));
  analyticsStore.set(a);
}

function record(type: string, label: string) {
  if (typeof window === "undefined") return;
  void supabase.from("analytics_events").insert({ type, label: label.slice(0, 200) });
}

export function trackPageView(path: string) {
  record("view", path);
}

export function trackProductClick(id: string) {
  record("product", id);
}

export function trackAdClick(id: string) {
  record("ad", id);
}

export function trackAddToCart(name: string) {
  record("cart", name);
}

export function trackCheckout(total: string) {
  record("checkout", total);
}

export function usePageView(path: string) {
  useEffect(() => {
    trackPageView(path);
  }, [path]);
}

export const sum = (r: Record<string, number>) => Object.values(r).reduce((a, b) => a + b, 0);
